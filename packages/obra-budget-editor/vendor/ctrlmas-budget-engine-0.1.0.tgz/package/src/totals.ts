/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

import type Decimal from 'decimal.js';
import { CONTRACT_SCALE, LINE_SCALE, type BudgetCurrency, type BudgetTotals, type IvaRate } from './contracts';
import { Dec, decimalOf as d, toDecimalString as s } from './decimal';
import { getKostprijs, recalculateItems } from './opencalc/calculation/calculator';
import { isStagartRowType, type CostItem, type ProjectFile } from './opencalc/types/costModel';

const ZERO = new Dec(0);
const HUNDRED = new Dec(100);
const RATES: readonly IvaRate[] = ['exento', '5', '10'];
const PERCENT: Record<IvaRate, Decimal> = { exento: ZERO, '5': new Dec(5), '10': new Dec(10) };
const ROOT_RATE: IvaRate = '10';
const line = (value: Decimal): Decimal => value.toDecimalPlaces(LINE_SCALE);

/**
 * Direct cost per IVA rate. A row's rate is its own `ivaRate` or its
 * parent's (root default '10'). A row counts as a leaf when it has no
 * children or its total is not the sum of its children (a post priced on
 * its own), so the groups always sum to the direct cost.
 */
const directByRate = (items: readonly CostItem[]): Map<IvaRate, Decimal> => {
	const children = new Map<string | null, CostItem[]>();
	for (const item of items) {
		if (!isStagartRowType(item.rowType)) {
			const list = children.get(item.parentId) ?? [];
			list.push(item);
			children.set(item.parentId, list);
		}
	}
	const groups = new Map<IvaRate, Decimal>();
	const walk = (node: CostItem, inherited: IvaRate): void => {
		const rate = node.ivaRate ?? inherited;
		const kids = children.get(node.id) ?? [];
		const total = d(node.total);
		if (kids.length === 0 || !kids.reduce((acc, kid) => acc.plus(d(kid.total)), ZERO).eq(total)) {
			groups.set(rate, (groups.get(rate) ?? ZERO).plus(total));
			return;
		}
		for (const kid of kids) {
			walk(kid, rate);
		}
	};
	for (const top of children.get(null) ?? []) {
		walk(top, ROOT_RATE);
	}
	return groups;
};

/**
 * Applies the money policy of contracts.ts to a budget, recalculated first:
 * - direct: sum of the quantized line amounts (top-level rows);
 * - markups: every staart row except upstream VAT rows, with its declared
 *   base (for afronding: the running total before it) and quantized amount;
 * - IVA per rate group: the amount before IVA (direct + markups) is split
 *   over the rates in proportion to their direct cost, each share quantized
 *   and the rounding rest given to the highest rate present. 'separado' adds
 *   tax = share × rate; 'incluido' derives base = share / (1 + rate) and
 *   tax = share − base, so base + tax equals the share exactly;
 * - total: sum of quantized amounts; adjustment: total rounded HALF_UP to
 *   CONTRACT_SCALE[currency] minus total.
 */
export const computeTotals = (budget: ProjectFile, currency: BudgetCurrency): BudgetTotals => {
	const items = recalculateItems(budget.items);
	const warnings: string[] = [];
	if (budget.schedule.currency !== currency) {
		warnings.push(`schedule.currency is ${JSON.stringify(budget.schedule.currency)}; totals use ${currency}`);
	}
	if (items.some(item => item.btwTarief != null)) {
		warnings.push('btwTarief (upstream Dutch VAT rate) is ignored; set ivaRate instead');
	}

	const direct = d(getKostprijs(items));
	let net = direct;
	const markups: { id: string; base: string; amount: string }[] = [];
	for (const item of items) {
		if (!isStagartRowType(item.rowType)) {
			continue;
		}
		if (item.rowType === 'staart_btw' || item.rowType === 'staart_btw_laag') {
			warnings.push(`${item.rowType} row ${item.id} (upstream Dutch VAT) contributes zero; IVA comes from ivaRate and ivaMode`);
			continue;
		}
		const breakdown = item.staartItemBreakdown;
		const amount = d(breakdown?.subtotaal);
		const base = item.rowType === 'staart_afronding' ? d(breakdown?.totaal).minus(amount) : d(breakdown?.bedrag);
		markups.push({ id: item.id, base: s(base), amount: s(amount) });
		net = net.plus(amount);
	}

	const groups = directByRate(items);
	const rates = RATES.filter(rate => groups.has(rate));
	if (rates.length === 0 && !net.isZero()) {
		rates.push(ROOT_RATE);
	}
	const mode = budget.schedule.ivaMode ?? 'separado';
	const iva: { rate: IvaRate; base: string; tax: string }[] = [];
	let allocated = ZERO;
	let taxes = ZERO;
	rates.forEach((rate, i) => {
		const share = i === rates.length - 1
			? net.minus(allocated)
			: direct.isZero() ? ZERO : line(net.times(groups.get(rate) ?? ZERO).div(direct));
		allocated = allocated.plus(share);
		const base = mode === 'incluido' ? line(share.times(HUNDRED).div(HUNDRED.plus(PERCENT[rate]))) : share;
		const tax = mode === 'incluido' ? share.minus(base) : line(share.times(PERCENT[rate]).div(HUNDRED));
		taxes = taxes.plus(tax);
		iva.push({ rate, base: s(base), tax: s(tax) });
	});

	const total = mode === 'incluido' ? net : net.plus(taxes);
	const contractTotal = total.toDecimalPlaces(CONTRACT_SCALE[currency]);
	return {
		currency,
		direct: s(direct),
		markups,
		iva,
		total: s(total),
		adjustment: s(contractTotal.minus(total)),
		contractTotal: s(contractTotal),
		warnings,
	};
};
