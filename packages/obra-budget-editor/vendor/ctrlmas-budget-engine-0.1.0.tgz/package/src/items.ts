/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

import { DERIVED_ITEM_FIELDS, type ItemInput, type ItemPosition } from './contracts';
import { sameJson } from './canonical';
import type { CostItem } from './opencalc/types/costModel';

export const DERIVED = new Set<string>(DERIVED_ITEM_FIELDS);

/** Own property or undefined, so keys like `__proto__` read as data. */
export const getOwn = (target: object, key: string): unknown =>
	Object.hasOwn(target, key) ? (target as Record<string, unknown>)[key] : undefined;

/** Sets an own property (or deletes it for undefined) without invoking setters. */
export const setOwn = (target: object, key: string, value: unknown): void => {
	if (value === undefined) {
		delete (target as Record<string, unknown>)[key];
		return;
	}
	Object.defineProperty(target, key, { value, writable: true, enumerable: true, configurable: true });
};

/** Copy of the item without the fields the calculator derives. */
export const stripDerived = (item: ItemInput): ItemInput => {
	const out: Record<string, unknown> = {};
	for (const key of Object.keys(item)) {
		if (!DERIVED.has(key)) {
			setOwn(out, key, getOwn(item, key));
		}
	}
	return out as unknown as ItemInput;
};

/** Equal non-derived content, ignoring the position (`parentId`). */
export const sameContent = (a: ItemInput, b: ItemInput): boolean =>
	sameJson({ ...stripDerived(a), parentId: null }, { ...stripDerived(b), parentId: null });

/** Position of every item: its parent and the previous sibling in array order. */
export const positionsOf = (items: readonly CostItem[]): Map<string, ItemPosition> => {
	const last = new Map<string | null, string>();
	const out = new Map<string, ItemPosition>();
	for (const item of items) {
		const parentId = item.parentId ?? null;
		out.set(item.id, { parentId, afterId: last.get(parentId) ?? null });
		last.set(parentId, item.id);
	}
	return out;
};
