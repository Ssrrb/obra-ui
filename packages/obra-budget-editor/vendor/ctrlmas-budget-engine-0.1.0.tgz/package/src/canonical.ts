/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

const write = (input: unknown): string | undefined => {
	let value = input;
	if (value !== null && typeof value === 'object' && typeof (value as { toJSON?: unknown }).toJSON === 'function') {
		value = (value as { toJSON: () => unknown }).toJSON();
	}
	if (value === null) {
		return 'null';
	}
	switch (typeof value) {
		case 'string':
		case 'boolean':
			return JSON.stringify(value);
		case 'number':
			return Number.isFinite(value) ? JSON.stringify(value) : 'null';
		case 'bigint':
			throw new TypeError('BigInt has no JSON representation');
		case 'object': {
			if (Array.isArray(value)) {
				return `[${value.map(entry => write(entry) ?? 'null').join(',')}]`;
			}
			const record = value as Record<string, unknown>;
			const parts: string[] = [];
			for (const key of Object.keys(record).sort()) {
				const entry = write(record[key]);
				if (entry !== undefined) {
					parts.push(`${JSON.stringify(key)}:${entry}`);
				}
			}
			return `{${parts.join(',')}}`;
		}
		default:
			return undefined;
	}
};

/**
 * JSON with object keys sorted by code unit at every level. Follows
 * JSON.stringify otherwise: `undefined` properties are omitted, non-finite
 * numbers become null. Throws for values without a JSON form.
 */
export const canonicalJson = (value: unknown): string => {
	const json = write(value);
	if (json === undefined) {
		throw new TypeError('Value has no JSON representation');
	}
	return json;
};

/** Equality by canonical JSON; `undefined` (absent) equals only itself. */
export const sameJson = (a: unknown, b: unknown): boolean => {
	if (a === undefined || b === undefined) {
		return a === b;
	}
	return canonicalJson(a) === canonicalJson(b);
};
