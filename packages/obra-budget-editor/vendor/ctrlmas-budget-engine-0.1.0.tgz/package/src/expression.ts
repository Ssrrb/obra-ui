/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

/**
 * Decimal port of OpenCalc's grid input evaluator (src/utils/numericInput.ts
 * and parseNlNumber in src/utils/formatting.ts at the commit in
 * PROVENANCE.md). Same tokens and grammar, but every operation runs on
 * decimal.js and the text is never turned into executable JavaScript.
 *
 * Locales: 'es-PY' follows upstream's NL rules (comma = decimal separator,
 * dot = thousands separator when combined with a comma or repeated);
 * 'plain' accepts only `.` as decimal separator and no thousands separator.
 */

import type Decimal from 'decimal.js';
import type { DecimalString } from './contracts';
import { Dec, MAX_FRACTION_DIGITS, normalizeDecimal } from './decimal';

export type NumberLocale = 'es-PY' | 'plain';

type Token = { readonly kind: 'num'; readonly value: Decimal } | { readonly kind: 'op'; readonly op: string };

/** Canonical text of a result rounded HALF_UP to 12 fraction digits, or null if it does not fit. */
const result = (value: Decimal): DecimalString | null => normalizeDecimal(value.toDecimalPlaces(MAX_FRACTION_DIGITS).toFixed());

/** A number token inside a formula (upstream parseFormulaNumber). */
const formulaNumber = (token: string, locale: NumberLocale): Decimal | null => {
	let normalized = token;
	if (locale === 'es-PY') {
		const lastComma = token.lastIndexOf(',');
		if (lastComma >= 0) {
			if (token.indexOf(',') !== lastComma) {
				return null;
			}
			normalized = token.replace(/\./g, '').replace(',', '.');
		} else if ((token.match(/\./g) ?? []).length > 1) {
			normalized = token.replace(/\./g, '');
		}
	}
	if (!/^\d*\.?\d+$/.test(normalized) && !/^\d+\.$/.test(normalized)) {
		return null;
	}
	const canonical = normalizeDecimal(normalized);
	return canonical === null ? null : new Dec(canonical);
};

const tokenize = (expr: string, locale: NumberLocale): Token[] | null => {
	const numberChar = locale === 'es-PY' ? /[0-9.,]/ : /[0-9.]/;
	const tokens: Token[] = [];
	let i = 0;
	while (i < expr.length) {
		const ch = expr[i]!;
		if (/\s/.test(ch)) {
			i++;
		} else if ('+-*/()'.includes(ch)) {
			tokens.push({ kind: 'op', op: ch });
			i++;
		} else if (numberChar.test(ch)) {
			let j = i;
			while (j < expr.length && numberChar.test(expr[j]!)) {
				j++;
			}
			const value = formulaNumber(expr.slice(i, j), locale);
			if (value === null) {
				return null;
			}
			tokens.push({ kind: 'num', value });
			i = j;
		} else {
			return null;
		}
	}
	return tokens;
};

/**
 * Evaluates `+ - * /`, parentheses and unary signs over decimal literals.
 * A leading `=` is allowed. Returns the result as canonical decimal text
 * rounded HALF_UP to 12 fraction digits, or null for empty or invalid
 * input (letters, function calls, a literal beyond 24 integer / 12 fraction
 * digits), division by zero, or a result beyond 24 integer digits.
 */
export const evaluateDecimalExpression = (text: string, locale: NumberLocale = 'es-PY'): DecimalString | null => {
	const body = text.trim().replace(/^=/, '');
	const tokens = tokenize(body, locale);
	if (!tokens || tokens.length === 0) {
		return null;
	}
	let pos = 0;
	const takeOp = (ops: string): string | null => {
		const t = tokens[pos];
		if (t && t.kind === 'op' && ops.includes(t.op)) {
			pos++;
			return t.op;
		}
		return null;
	};

	// expr = term ((+|-) term)*, term = factor ((*|/) factor)*, factor = [+-]* (number | '(' expr ')')
	const parseExpr = (): Decimal | null => {
		let left = parseTerm();
		let op: string | null;
		while (left !== null && (op = takeOp('+-')) !== null) {
			const right = parseTerm();
			left = right === null ? null : op === '+' ? left.plus(right) : left.minus(right);
		}
		return left;
	};

	const parseTerm = (): Decimal | null => {
		let left = parseFactor();
		let op: string | null;
		while (left !== null && (op = takeOp('*/')) !== null) {
			const right = parseFactor();
			if (right === null || (op === '/' && right.isZero())) {
				return null;
			}
			left = op === '*' ? left.times(right) : left.div(right);
		}
		return left;
	};

	const parseFactor = (): Decimal | null => {
		let negative = false;
		let op: string | null;
		while ((op = takeOp('+-')) !== null) {
			negative = op === '-' ? !negative : negative;
		}
		const t = tokens[pos];
		let value: Decimal | null = null;
		if (t?.kind === 'num') {
			pos++;
			value = t.value;
		} else if (t?.kind === 'op' && t.op === '(') {
			pos++;
			const inner = parseExpr();
			value = inner !== null && takeOp(')') !== null ? inner : null;
		}
		return value !== null && negative ? value.negated() : value;
	};

	const value = parseExpr();
	return value === null || pos !== tokens.length ? null : result(value);
};

/** A plain number as typed in a cell (upstream parseNlNumber, strict: trailing text is invalid). */
const parseLocaleNumber = (input: string, locale: NumberLocale): DecimalString | null => {
	let cleaned = input.trim();
	if (locale === 'es-PY') {
		if (cleaned.includes(',')) {
			cleaned = cleaned.replace(/\./g, '').replace(',', '.');
		} else {
			const dots = (cleaned.match(/\./g) ?? []).length;
			if (dots > 1) {
				cleaned = cleaned.replace(/\./g, '');
			} else if (dots === 1 && /^\d{3}$/.test(cleaned.slice(cleaned.indexOf('.') + 1))) {
				// One dot followed by exactly three digits is a thousands separator ("1.234" → 1234).
				cleaned = cleaned.replace('.', '');
			}
		}
	}
	return normalizeDecimal(cleaned.replace(/^\+/, ''));
};

/**
 * Grid input for a number cell, as upstream parseNumericInput: a plain
 * number ("6,66", "1.234,56", "-15,5") or a formula ("=12,2*2,22",
 * "17,7+5"). Without `=`, text is a formula only with `* / ( )` or a `+`/`-`
 * after a digit; a failed formula without `=` is retried as a plain number.
 * Returns canonical decimal text or null.
 */
export const parseDecimalInput = (input: string, locale: NumberLocale = 'es-PY'): DecimalString | null => {
	const trimmed = input.trim();
	const isFormula = trimmed.startsWith('=');
	const body = isFormula ? trimmed.slice(1) : trimmed;
	if (!body.trim()) {
		return null;
	}
	const looksLikeExpr = isFormula || /[*/()]/.test(body) || /\d\s*[+-]/.test(body);
	if (!looksLikeExpr) {
		return parseLocaleNumber(body, locale);
	}
	return evaluateDecimalExpression(body, locale) ?? (isFormula ? null : parseLocaleNumber(body, locale));
};
