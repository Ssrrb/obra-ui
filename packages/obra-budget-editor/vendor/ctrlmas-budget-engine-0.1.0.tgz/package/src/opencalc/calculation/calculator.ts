import type Decimal from 'decimal.js';
import type { CostItem, StaartItemBreakdown } from '../types/costModel';
import { isStagartRowType } from '../types/costModel';
import { LINE_SCALE, type DecimalString } from '../../contracts';
import { Dec, decimalOf as d, toDecimalString as s } from '../../decimal';

// ctrl schema 2: every amount is a DecimalString and every operation runs on
// decimal.js (see PROVENANCE.md). Line amounts and markups are quantized to
// LINE_SCALE HALF_UP; other derived values keep 12 fraction digits.
const ZERO = new Dec(0);
const ONE = new Dec(1);
const HUNDRED = new Dec(100);
const line = (value: Decimal): Decimal => value.toDecimalPlaces(LINE_SCALE);
const sum = (values: readonly Decimal[]): Decimal => values.reduce((acc, value) => acc.plus(value), ZERO);
const pctOf = (item: CostItem): Decimal => d(item.staartPercentage).div(HUNDRED);


/**
 * Canonieke item-volgorde: depth-first per parentId, zodat kinderen altijd
 * direct (aaneengesloten) onder hun ouder staan. Dit is dé invariant waar de
 * rest van de app op leunt — rapportages, prints, exporters, nummering en
 * verplaats-/invoeglogica lezen de array sequentieel en zijn alleen correct
 * als deze volgorde klopt. Importeurs en de MCP-bridge voegen items echter
 * plat (achteraan) toe; daarom normaliseert recalculateItems de volgorde bij
 * elke herberekening.
 *
 * Regels:
 * - sibling-volgorde = bestaande relatieve array-volgorde (stabiel; respecteert
 *   versleep-acties die alléén de array herordenen);
 * - depth wordt her-afgeleid uit de boom; sortOrder wordt vastgelegd als de
 *   uiteindelijke sibling-index (voor externe lezers van opgeslagen bestanden);
 * - onbereikbare items (wees met onbekende parentId, of cyclus) blijven
 *   behouden en komen ná de reguliere boom — data verdwijnt nooit stilletjes;
 * - staart_* regels staan altijd helemaal achteraan.
 */
export function normalizeItemOrder(items: CostItem[]): CostItem[] {
  const byParent = new Map<string | null, CostItem[]>();
  const staart: CostItem[] = [];
  for (const item of items) {
    if (item.parentId === undefined) item.parentId = null;
    if (isStagartRowType(item.rowType)) {
      staart.push(item);
      continue;
    }
    const key = item.parentId;
    const list = byParent.get(key);
    if (list) list.push(item);
    else byParent.set(key, [item]);
  }

  const ordered: CostItem[] = [];
  const seen = new Set<string>();
  const walk = (parentId: string | null, depth: number) => {
    const kids = byParent.get(parentId);
    if (!kids) return;
    for (let i = 0; i < kids.length; i++) {
      const item = kids[i]!;
      if (seen.has(item.id)) continue; // cyclus-guard
      seen.add(item.id);
      item.depth = depth;
      item.sortOrder = i;
      ordered.push(item);
      walk(item.id, depth + 1);
    }
  };
  walk(null, 0);

  // Wezen/cycli: behouden in hun bestaande relatieve volgorde.
  for (const item of items) {
    if (!isStagartRowType(item.rowType) && !seen.has(item.id)) {
      seen.add(item.id);
      ordered.push(item);
    }
  }

  return [...ordered, ...staart];
}

export function recalculateItems(items: CostItem[], tarieven?: Record<string, DecimalString>): CostItem[] {
  const result = normalizeItemOrder(items.map(item => ({ ...item })));

  // Recompute laborPrice from tariefGroep + tarieven when tarieven are provided.
  // Alleen voor regels mét een productienorm: laborPrice = norm × uurtarief.
  // Regels zonder norm hebben een direct ingevuld uurloon — dat moet blijven
  // staan (norm=null → 0 × tarief zou het uurloon stilletjes wissen bij
  // elke willekeurige bewerking elders in de begroting).
  if (tarieven) {
    for (const item of result) {
      if (item.rowType === 'regel' && item.tariefGroep && item.normQuantity != null) {
        const tarief = d(tarieven[item.tariefGroep]);
        item.laborPrice = s(d(item.normQuantity).times(tarief), `items.${item.id}.laborPrice`);
      }
    }
  }

  // Build parent->children map
  const childrenMap = new Map<string | null, CostItem[]>();
  for (const item of result) {
    const list = childrenMap.get(item.parentId) ?? [];
    list.push(item);
    childrenMap.set(item.parentId, list);
  }

  // First pass: calculate leaf items (begrotingspost without children, and regel rows)
  for (const item of result) {
    if (item.rowType === 'regel') {
      // Hoeveelheid = Aantal × Productienorm / Productiecapaciteit
      const qty = d(item.quantity);
      const norm = d(item.normQuantity);
      const cap = item.normFactor == null ? ONE : d(item.normFactor);
      const nup = d(item.normUnitPrice);
      const lab = d(item.laborPrice);
      const hoeveelheid = qty.times(norm).div(cap.isZero() ? ONE : cap);
      // Two calculation models:
      // UI-2/WpCalc (work-based): total = aantal × (prijs + laborPrice)
      //   Used when: laborPrice > 0, or norm=0 with direct price (onderaanneming etc.)
      // UI-1 (resource-based): total = hoeveelheid × prijs/middel
      //   Used when: norm > 0 and no separate laborPrice
      let amount: Decimal;
      if (lab.gt(0) || norm.isZero()) {
        // WpCalc / direct-price model: kosteneh = normUnitPrice + laborPrice per unit
        amount = qty.times(nup.plus(lab));
      } else {
        // UI-1 model: eenheidsprijs = hoeveelheid × prijs/middel
        amount = hoeveelheid.times(nup);
      }
      // ctrl: unitPrice keeps the unrounded amount; the line amount is quantized.
      item.unitPrice = s(amount, `items.${item.id}.unitPrice`);
      item.total = s(line(amount), `items.${item.id}.total`);
    } else if (item.rowType === 'begrotingspost' || item.rowType === 'bewakingspost') {
      // Kale (bewakings)post zonder kinderen: eigen prijs telt —
      // prijs/middel (normUnitPrice) plus materiaal en loon.
      const children = childrenMap.get(item.id) ?? [];
      if (children.length === 0) {
        const unitPrice = d(item.normUnitPrice).plus(d(item.materialPrice)).plus(d(item.laborPrice));
        item.unitPrice = s(unitPrice, `items.${item.id}.unitPrice`);
        item.total = s(line(d(item.quantity).times(unitPrice)), `items.${item.id}.total`);
      }
      // If has children, total will be computed bottom-up below
    }
  }

  // Eigen berekening van een (bewakings)post: aantal × (prijs/middel + mat + loon).
  // Gebruikt als de kinderen (nog) niets opleveren — een op de post ingevulde
  // prijs mag niet verdwijnen zodra er een lege bewakingspost of tekstregel
  // onder hangt.
  const ownTotal = (item: CostItem): Decimal => {
    const price = d(item.normUnitPrice).plus(d(item.materialPrice)).plus(d(item.laborPrice));
    return line(d(item.quantity).times(price));
  };

  // Special first pass for bewakingspost: quantity acts as multiplier
  // Must be done before second pass so the bewakingspost subtree total is correct
  // (handled in second pass after child summation)

  // Second pass: bottom-up summation for containers.
  //
  // `rollup` bepaalt totaal en eenheidsprijs van één container (hoofdstuk,
  // begrotingspost of bewakingspost) uit zijn kinderen. Dezelfde functie
  // dient voor geneste containers én voor items op het hoogste niveau: een
  // begrotingspost zonder hoofdstuk erboven (bv. uit een geïmporteerde
  // prijsdatabase) kreeg voorheen wél een totaal maar geen afgeleide
  // eenheidsprijs, omdat alleen de kind-tak die afleiding kende.
  function rollup(item: CostItem): void {
    const children = childrenMap.get(item.id) ?? [];
    if (children.length === 0) return;
    const childSum = calcTotal(item.id);
    const own = (item.rowType !== 'chapter' && childSum.isZero()) ? ownTotal(item) : ZERO;
    if (!own.isZero()) {
      // Kinderen leveren (nog) niets op: de eigen post-prijs telt door.
      const qty = d(item.quantity);
      item.total = s(own, `items.${item.id}.total`);
      item.unitPrice = s(qty.isZero() ? own : own.div(qty), `items.${item.id}.unitPrice`);
      return;
    }
    // Total is always the bottom-up sum of children
    item.total = s(childSum, `items.${item.id}.total`);
    const childUnitPrices = () => sum(children
      .filter(c => !isStagartRowType(c.rowType))
      .map(c => d(c.unitPrice)));
    if (item.rowType === 'bewakingspost') {
      // Bewakingspost: unitPrice = sum of child unitPrices
      item.unitPrice = s(childUnitPrices(), `items.${item.id}.unitPrice`);
    } else if (item.rowType === 'begrotingspost') {
      // Begrotingspost: unitPrice = total / quantity (afgeleide waarde voor weergave)
      item.unitPrice = s((item.quantity != null && !d(item.quantity).isZero())
        ? childSum.div(d(item.quantity))
        : childUnitPrices(), `items.${item.id}.unitPrice`);
    }
  }

  function calcTotal(parentId: string): Decimal {
    const children = childrenMap.get(parentId) ?? [];
    let total = ZERO;
    for (const child of children) {
      if (child.rowType === 'chapter' || child.rowType === 'begrotingspost' || child.rowType === 'bewakingspost') {
        rollup(child);
      }
      // Only include non-staart items in parent sums
      if (!isStagartRowType(child.rowType)) {
        total = total.plus(d(child.total));
      }
    }
    return total;
  }

  // Totals (and derived unit prices) for ALL top-level items that have children
  for (const item of result) {
    if (item.parentId === null && !isStagartRowType(item.rowType)) {
      rollup(item);
    }
  }

  // Third pass: calculate staartkosten (cascading surcharges)
  const totaalKolommen = sum(result
    .filter(item => item.parentId === null && !isStagartRowType(item.rowType))
    .map(item => d(item.total)));

  // Sum of only the onderaanneming portion (regel rows with resourceType === 'onderaannemer')
  const oaPortie = sum(result
    .filter(item => item.rowType === 'regel' && item.resourceType === 'onderaannemer')
    .map(item => d(item.total)));

  // Track running totals for the Bouw 1 cascading staart model
  let kostprijs = totaalKolommen; // will accumulate ak_oa + abk + garanties + wvpm
  let runningTotal = totaalKolommen; // legacy model running total

  // Display fields of a percentage row; returns its (quantized) amount.
  const percentRow = (item: CostItem, base: Decimal): Decimal => {
    item.quantity = item.staartPercentage ?? '0';
    item.unit = '%';
    item.unitPrice = s(base.div(HUNDRED), `items.${item.id}.unitPrice`);
    const amount = line(base.times(pctOf(item)));
    item.total = s(amount, `items.${item.id}.total`);
    return amount;
  };

  for (const item of result) {
    if (!isStagartRowType(item.rowType)) continue;

    // ── Legacy staart types (backward compatibility) ──
    if (item.rowType === 'staart_ukk') {
      runningTotal = totaalKolommen.plus(percentRow(item, totaalKolommen));
      kostprijs = runningTotal;
    } else if (item.rowType === 'staart_ak') {
      runningTotal = runningTotal.plus(percentRow(item, runningTotal));
      kostprijs = runningTotal;
    } else if (item.rowType === 'staart_wr') {
      runningTotal = runningTotal.plus(percentRow(item, runningTotal));

    // ── Bouw 1 staart model ──
    // Phase 1: over totaal kolommen (raw directe kosten)
    } else if (item.rowType === 'staart_ak_oa') {
      // AK over onderaanneming: percentage over only the OA portion
      kostprijs = totaalKolommen.plus(percentRow(item, oaPortie));
      runningTotal = kostprijs;
    } else if (item.rowType === 'staart_abk' || item.rowType === 'staart_garanties' || item.rowType === 'staart_wvpm') {
      // Algemene bedrijfskosten, garanties, werkvoorbereiding & PM: percentage over totaal kolommen
      kostprijs = kostprijs.plus(percentRow(item, totaalKolommen));
      runningTotal = kostprijs;

    // Phase 2: over kostprijs (= totaal kolommen + phase 1 surcharges)
    } else if (item.rowType === 'staart_risico' || item.rowType === 'staart_winst' || item.rowType === 'staart_verzekering') {
      runningTotal = runningTotal.plus(percentRow(item, kostprijs));

    // Phase 3: BTW. ctrl: upstream Dutch VAT rows stay in the document but
    // contribute zero; IVA comes from ivaRate/ivaMode (see computeTotals).
    } else if (item.rowType === 'staart_btw' || item.rowType === 'staart_btw_laag') {
      item.quantity = item.staartPercentage ?? '0';
      item.unit = '%';
      item.unitPrice = s(runningTotal.div(HUNDRED), `items.${item.id}.unitPrice`);
      item.total = '0';

    // ── Afronding (shared between legacy and Bouw 1) ──
    } else if (item.rowType === 'staart_afronding') {
      const rounded = runningTotal.div(10).toDecimalPlaces(0).times(10);
      item.total = s(rounded.minus(runningTotal), `items.${item.id}.total`);
      item.quantity = null;
      item.unitPrice = '0';
      runningTotal = rounded;
    }
  }

  // Fourth pass: compute hierarchical Nr values
  const siblingGroups = new Map<string | null, CostItem[]>();
  for (const item of result) {
    const key = item.parentId;
    const list = siblingGroups.get(key) ?? [];
    list.push(item);
    siblingGroups.set(key, list);
  }

  function assignNr(parentId: string | null, parentNr: string) {
    const siblings = siblingGroups.get(parentId) ?? [];
    let counter = 0;
    for (const item of siblings) {
      // Staart, tekstregel, and witregel rows don't get hierarchical numbers
      if (isStagartRowType(item.rowType) || item.rowType === 'tekstregel' || item.rowType === 'witregel') {
        item.nr = '';
        continue;
      }
      counter++;
      // Top-level chapters: use their code as Nr when available (e.g. "60" instead of "19")
      let segment: string;
      if (!parentId && item.rowType === 'chapter' && item.code) {
        segment = item.code;
      } else {
        segment = String(counter).padStart(2, '0');
      }
      item.nr = parentNr ? `${parentNr}.${segment}` : segment;
      // Recurse into children if this is a container
      if (item.rowType === 'chapter' || item.rowType === 'begrotingspost' || item.rowType === 'bewakingspost') {
        assignNr(item.id, item.nr);
      }
    }
  }
  assignNr(null, '');

  // Add live staart breakdowns (replaces stale schedule.staartRows cache)
  return computeStaartItemBreakdowns(result);
}

export interface KostprijsBreakdown {
  loon: DecimalString;
  materiaal: DecimalString;
  materieel: DecimalString;
  stelpost: DecimalString;
  onderaanneming: DecimalString;
}

type Columns = { -readonly [K in keyof KostprijsBreakdown]: Decimal };

/** computeKostprijsBreakdown on decimals (ctrl: shared by the breakdowns below). */
function kostprijsColumns(items: CostItem[]): Columns {
  const out: Columns = {
    loon: ZERO, materiaal: ZERO, materieel: ZERO, stelpost: ZERO, onderaanneming: ZERO,
  };
  for (const item of items) {
    if (item.rowType !== 'regel') continue;
    const qty = d(item.quantity);
    const lab = d(item.laborPrice);
    const matPrice = d(item.normUnitPrice);
    const total = d(item.total);

    if (item.resourceType === 'onderaannemer') {
      out.onderaanneming = out.onderaanneming.plus(total);
      continue;
    }

    const splitLoon = lab.times(qty);
    const splitMat = matPrice.times(qty);
    const split = splitLoon.plus(splitMat);
    const usedSplit = split.minus(total).abs().lt(0.01) && split.gt(0);
    // ctrl: the loon part is quantized and the resource part is the rest of
    // the (quantized) line amount, so both columns sum to it exactly.
    const loonAmt = usedSplit ? line(splitLoon) : ZERO;
    const matAmt = usedSplit ? total.minus(loonAmt) : total;

    out.loon = out.loon.plus(loonAmt);

    switch (item.resourceType) {
      case 'arbeid':
        // 'arbeid' regel: total goes to loon (in addition to any split-derived loon)
        out.loon = out.loon.plus(matAmt);
        break;
      case 'materieel':
        out.materieel = out.materieel.plus(matAmt);
        break;
      case 'overig':
        out.stelpost = out.stelpost.plus(matAmt);
        break;
      case 'materiaal':
      default:
        out.materiaal = out.materiaal.plus(matAmt);
        break;
    }
  }
  return out;
}

/** Group regel totals by resourceType to produce kostprijs columns
 *  (loon, materiaal, materieel, stelpost, onderaanneming).
 *
 *  Splits a regel with a separate laborPrice into a loon part and a
 *  resource-column part, when the split matches the row's total. */
export function computeKostprijsBreakdown(items: CostItem[]): KostprijsBreakdown {
  const out = kostprijsColumns(items);
  return {
    loon: s(out.loon), materiaal: s(out.materiaal), materieel: s(out.materieel),
    stelpost: s(out.stelpost), onderaanneming: s(out.onderaanneming),
  };
}

/**
 * Directe kosten (excl. staart) die onder het lage btw-tarief vallen, op
 * basis van de per-onderdeel markering (CostItem.btwTarief). Kinderen erven
 * het tarief van hun ouder; alleen bladeren (rijen zonder kinderen) tellen
 * mee, zodat een hoog-override binnen een laag hoofdstuk correct aftrekt.
 *
 * ctrl: kept for upstream callers; btwTarief no longer feeds any amount.
 */
export function computeBtwLaagDirect(items: CostItem[]): DecimalString {
  const childrenOf = new Map<string | null, CostItem[]>();
  for (const it of items) {
    if (isStagartRowType(it.rowType)) continue;
    const list = childrenOf.get(it.parentId) ?? [];
    list.push(it);
    childrenOf.set(it.parentId, list);
  }
  const walk = (node: CostItem, inherited: 'hoog' | 'laag'): Decimal => {
    const eff = node.btwTarief ?? inherited;
    const kids = childrenOf.get(node.id);
    if (!kids || kids.length === 0) {
      return eff === 'laag' ? d(node.total) : ZERO;
    }
    return sum(kids.map(k => walk(k, eff)));
  };
  return s(sum((childrenOf.get(null) ?? []).map(top => walk(top, 'hoog'))));
}

type Breakdown = { -readonly [K in keyof StaartItemBreakdown]: Decimal };

/** Returns items with staart_* rows updated to have staartItemBreakdown filled in.
 *  Pure: returns new array, leaves input untouched (except non-staart items are passed through).
 *
 *  ctrl: every markup is quantized to LINE_SCALE after applying it to its
 *  base; staart_btw/staart_btw_laag contribute zero. */
export function computeStaartItemBreakdowns(items: CostItem[]): CostItem[] {
  const kostprijs = kostprijsColumns(items);
  const totaalKolommen =
    kostprijs.loon.plus(kostprijs.materiaal).plus(kostprijs.materieel)
      .plus(kostprijs.stelpost).plus(kostprijs.onderaanneming);

  // Track running cumulative — alles EXCLUSIEF btw.
  let cumulative = totaalKolommen;
  // Resource-column running totals also accumulate
  const running = { ...kostprijs };

  const bdOf = new Map<string, Breakdown>();
  const staartItems = items.filter(i => i.rowType?.startsWith('staart_'));
  const empty = (totaal: Decimal): Breakdown => ({
    loon: ZERO, materiaal: ZERO, materieel: ZERO, stelpost: ZERO, onderaanneming: ZERO,
    bedrag: ZERO, subtotaal: ZERO, totaal,
  });

  // Pass 1: alle niet-btw-staartregels in arrayvolgorde (cascade, excl. btw)
  for (const item of staartItems) {
    if (item.rowType === 'staart_btw' || item.rowType === 'staart_btw_laag') continue;
    const pct = pctOf(item);
    // Vlakke staart (BasCalc): percentage over de directe kosten i.p.v.
    // over het opgehoogde bedrag (cascade). Zie CostItem.staartBasis.
    const vlak = item.staartBasis === 'kostprijs';

    let bd = empty(cumulative);

    switch (item.rowType) {
      case 'staart_ak_oa': {
        const v = line(running.onderaanneming.times(pct));
        // ctrl: bedrag carries the declared base (upstream left it 0).
        bd = { ...bd, onderaanneming: v, bedrag: running.onderaanneming, subtotaal: v };
        running.onderaanneming = running.onderaanneming.plus(v);
        cumulative = cumulative.plus(v);
        bd.totaal = cumulative;
        break;
      }
      case 'staart_abk':
      case 'staart_garanties':
      case 'staart_wvpm': {
        // Vlak: over de oorspronkelijke kostprijskolommen; cascade: over de
        // running (door eerdere opslagen opgehoogde) kolommen.
        const bases = vlak
          ? [kostprijs.loon, kostprijs.materiaal, kostprijs.materieel]
          : [running.loon, running.materiaal, running.materieel];
        const base = sum(bases);
        const v = line(base.times(pct));
        // ctrl: the quantized markup is split over the columns; the rounding
        // rest goes to the largest base so the columns sum to v exactly.
        const parts = bases.map(b => line(b.times(pct)));
        let largest = 0;
        bases.forEach((b, i) => { if (b.abs().gt(bases[largest]!.abs())) largest = i; });
        parts[largest] = parts[largest]!.plus(v.minus(sum(parts)));
        const [loon, mat, matrl] = parts as [Decimal, Decimal, Decimal];
        bd = { ...bd, loon, materiaal: mat, materieel: matrl, bedrag: base, subtotaal: v };
        if (!vlak) {
          running.loon = running.loon.plus(loon);
          running.materiaal = running.materiaal.plus(mat);
          running.materieel = running.materieel.plus(matrl);
        }
        cumulative = cumulative.plus(v);
        bd.totaal = cumulative;
        break;
      }
      // Legacy staart_ukk/ak/wr — percentage-of-cumulative (of vlak over kostprijs)
      case 'staart_risico':
      case 'staart_winst':
      case 'staart_verzekering':
      case 'staart_ukk':
      case 'staart_ak':
      case 'staart_wr': {
        const base = vlak ? totaalKolommen : cumulative;
        const v = line(base.times(pct));
        bd = { ...bd, bedrag: base, subtotaal: v };
        cumulative = cumulative.plus(v);
        bd.totaal = cumulative;
        break;
      }
      case 'staart_afronding': {
        if (item.staartVastBedrag != null) {
          // Handmatig ingevulde afronding: vast bedrag.
          const v = line(d(item.staartVastBedrag));
          bd = { ...bd, subtotaal: v };
          cumulative = cumulative.plus(v);
        } else if (item.staartDoelbedrag != null) {
          // Vaste sluitpost: doelbedrag = gewenst totaal excl. btw incl.
          // opslagen; de afronding is het verschil met de berekende som.
          const doel = line(d(item.staartDoelbedrag));
          bd = { ...bd, subtotaal: doel.minus(cumulative) };
          cumulative = doel;
        } else {
          // Automatisch afronden op de ingestelde stap; standaard 0 =
          // niet afronden (afronding blijft € 0,00 tot je een stap kiest).
          const stap = d(item.staartAfrondingStap);
          const rounded = stap.gt(0)
            ? line(cumulative.div(stap).toDecimalPlaces(0).times(stap))
            : cumulative;
          bd = { ...bd, subtotaal: rounded.minus(cumulative) };
          cumulative = rounded;
        }
        bd.totaal = cumulative;
        break;
      }
    }

    bdOf.set(item.id, bd);
  }

  // Pass 2 (ctrl): upstream applied Dutch VAT (hoog/laag) over the excl
  // total here. In schema 2 these rows contribute zero; IVA is computed per
  // rate group by computeTotals.
  for (const item of staartItems) {
    if (item.rowType === 'staart_btw' || item.rowType === 'staart_btw_laag') {
      bdOf.set(item.id, empty(cumulative));
    }
  }

  return items.map((item) => {
    const bd = bdOf.get(item.id);
    if (!bd) return item;
    const path = `items.${item.id}.staartItemBreakdown`;
    const staartItemBreakdown: StaartItemBreakdown = {
      loon: s(bd.loon, path), materiaal: s(bd.materiaal, path), materieel: s(bd.materieel, path),
      stelpost: s(bd.stelpost, path), onderaanneming: s(bd.onderaanneming, path),
      bedrag: s(bd.bedrag, path), subtotaal: s(bd.subtotaal, path), totaal: s(bd.totaal, path),
    };
    return { ...item, staartItemBreakdown, total: staartItemBreakdown.subtotaal };
  });
}

/** Sum of all top-level items (including staartkosten) = aanneemsom */
export function getGrandTotal(items: CostItem[]): DecimalString {
  return getStaartBreakdown(items).aanneemsomAfgerond;
}

/** Sum of only non-staart top-level items = kostprijs (directe kosten) */
export function getKostprijs(items: CostItem[]): DecimalString {
  return s(sum(items
    .filter(item => item.parentId === null && !isStagartRowType(item.rowType))
    .map(item => d(item.total))));
}

/** Get the aanneemsom breakdown for display purposes */
export interface StaartBreakdown {
  // Legacy fields (backward compatible)
  kostprijs: DecimalString;
  ukkAmount: DecimalString;
  ukkPercentage: DecimalString;
  subtotaal1: DecimalString;
  akAmount: DecimalString;
  akPercentage: DecimalString;
  subtotaal2: DecimalString;
  wrAmount: DecimalString;
  wrPercentage: DecimalString;
  aanneemsom: DecimalString;
  afronding: DecimalString;
  aanneemsomAfgerond: DecimalString;
  // Bouw 1 model fields
  totaalKolommen: DecimalString;
  akOaAmount: DecimalString;
  akOaPercentage: DecimalString;
  abkAmount: DecimalString;
  abkPercentage: DecimalString;
  garantiesAmount: DecimalString;
  garantiesPercentage: DecimalString;
  wvpmAmount: DecimalString;
  wvpmPercentage: DecimalString;
  kostprijsBouw1: DecimalString;       // totaalKolommen + ak_oa + abk + garanties + wvpm (Bouw 1 staart model)
  risicoAmount: DecimalString;
  risicoPercentage: DecimalString;
  winstAmount: DecimalString;
  winstPercentage: DecimalString;
  verzekeringAmount: DecimalString;
  verzekeringPercentage: DecimalString;
  aanneemsomExcl: DecimalString;        // kostprijsBouw1 + risico + winst + verzekering
  btwAmount: DecimalString;
  btwPercentage: DecimalString;
  /** Grondslag waarover het hoge btw-tarief rekent (excl-eind − lage grondslag). */
  btwGrondslag: DecimalString;
  btwLaagAmount: DecimalString;
  btwLaagPercentage: DecimalString;
  /** Ingevulde grondslag voor het lage tarief (0 = niet in gebruik). */
  btwLaagGrondslag: DecimalString;
}

export function getStaartBreakdown(items: CostItem[]): StaartBreakdown {
  const totaalKolommen = d(getKostprijs(items));
  const amount: Partial<Record<string, Decimal>> = {};
  const percentage: Partial<Record<string, DecimalString>> = {};
  const grondslag: Partial<Record<string, Decimal>> = {};
  for (const item of items) {
    if (!isStagartRowType(item.rowType)) continue;
    // Last row of each type wins, as upstream's per-type assignments.
    amount[item.rowType] = d(item.total);
    percentage[item.rowType] = item.staartPercentage ?? '0';
    grondslag[item.rowType] = d(item.staartItemBreakdown?.bedrag);
  }
  const a = (rowType: string): Decimal => amount[rowType] ?? ZERO;
  const p = (rowType: string): DecimalString => rowType === 'staart_afronding' ? '0' : percentage[rowType] ?? '0';

  // Legacy cascade
  const subtotaal1 = totaalKolommen.plus(a('staart_ukk'));
  const subtotaal2 = subtotaal1.plus(a('staart_ak'));

  // Bouw 1 cascade
  const phase1 = sum([a('staart_ak_oa'), a('staart_abk'), a('staart_garanties'), a('staart_wvpm')]);
  const phase2 = sum([a('staart_risico'), a('staart_winst'), a('staart_verzekering')]);
  const kostprijsBouw1 = totaalKolommen.plus(phase1);
  const aanneemsomExcl = kostprijsBouw1.plus(phase2);

  // Combined: use whichever model is active (legacy or Bouw 1)
  // Legacy aanneemsom = subtotaal2 + wrAmount, Bouw 1 = aanneemsomExcl
  const aanneemsom = subtotaal2.plus(a('staart_wr')).plus(phase1).plus(phase2);
  const aanneemsomAfgerond = aanneemsom.plus(a('staart_btw')).plus(a('staart_btw_laag')).plus(a('staart_afronding'));

  return {
    kostprijs: s(totaalKolommen), totaalKolommen: s(totaalKolommen),
    ukkAmount: s(a('staart_ukk')), ukkPercentage: p('staart_ukk'), subtotaal1: s(subtotaal1),
    akAmount: s(a('staart_ak')), akPercentage: p('staart_ak'), subtotaal2: s(subtotaal2),
    wrAmount: s(a('staart_wr')), wrPercentage: p('staart_wr'),
    aanneemsom: s(aanneemsom), afronding: s(a('staart_afronding')), aanneemsomAfgerond: s(aanneemsomAfgerond),
    akOaAmount: s(a('staart_ak_oa')), akOaPercentage: p('staart_ak_oa'),
    abkAmount: s(a('staart_abk')), abkPercentage: p('staart_abk'),
    garantiesAmount: s(a('staart_garanties')), garantiesPercentage: p('staart_garanties'),
    wvpmAmount: s(a('staart_wvpm')), wvpmPercentage: p('staart_wvpm'),
    kostprijsBouw1: s(kostprijsBouw1),
    risicoAmount: s(a('staart_risico')), risicoPercentage: p('staart_risico'),
    winstAmount: s(a('staart_winst')), winstPercentage: p('staart_winst'),
    verzekeringAmount: s(a('staart_verzekering')), verzekeringPercentage: p('staart_verzekering'),
    aanneemsomExcl: s(aanneemsomExcl),
    btwAmount: s(a('staart_btw')), btwPercentage: p('staart_btw'), btwGrondslag: s(grondslag['staart_btw'] ?? ZERO),
    btwLaagAmount: s(a('staart_btw_laag')), btwLaagPercentage: p('staart_btw_laag'), btwLaagGrondslag: s(grondslag['staart_btw_laag'] ?? ZERO),
  };
}
