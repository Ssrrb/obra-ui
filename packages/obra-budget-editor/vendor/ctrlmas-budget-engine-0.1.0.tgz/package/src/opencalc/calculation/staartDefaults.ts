import type { CostItem, RowType } from '../types/costModel';
import type { DecimalString } from '../../contracts';

/** Build a single staart_* CostItem with sensible defaults. */
export function makeStaartItem(
  rowType: RowType,
  description: string,
  pct: DecimalString | null,
  sortOrder: number,
): CostItem {
  return {
    id: crypto.randomUUID(),
    parentId: null,
    sortOrder,
    code: '',
    description,
    unit: pct !== null ? '%' : 'st',
    quantity: pct,
    materialPrice: null,
    laborPrice: null,
    unitPrice: '0',
    total: '0',
    isCollapsed: false,
    depth: 0,
    notes: '',
    ifcGuid: '',
    rowType,
    staartPercentage: pct,
    nr: '',
    normQuantity: null,
    normFactor: null,
    normDivisor: null,
    normUnitPrice: null,
    resourceType: null,
    resourceLibraryId: null,
    verrekenbaar: null,
    tariefGroep: null,
  };
}

interface CachedStaartRow {
  label?: string;
  percentage?: DecimalString | null;
}

/** Try to find a cached staart row's percentage by (case-insensitive) label substring. */
function findPct(rows: CachedStaartRow[] | undefined, label: string): DecimalString | null {
  if (!rows) return null;
  const needle = label.toLowerCase();
  const row = rows.find((r) => {
    const l = (r?.label ?? '').toLowerCase();
    return l.includes(needle);
  });
  if (!row) return null;
  return row.percentage ?? null;
}

/**
 * Synthesize the default staart: one K row (gastos generales) over the direct
 * cost, as wiki/docs/domain/budgets.mdx defines it. Keeps the percentage of a
 * cached `schedule.staartRows` K row. IVA is no staart row: it comes from
 * `ivaRate` (root default 10) and `ivaMode` (see contracts.ts).
 */
export function synthesizeStaartItems(schedule: any): CostItem[] {
  const cached = (schedule?.staartRows as CachedStaartRow[] | undefined) ?? undefined;
  const k = makeStaartItem('staart_ak', 'Gastos generales (K)', findPct(cached, 'gastos generales') ?? '10', 9000);
  k.staartBasis = 'kostprijs';
  return [k];
}

/**
 * Zorg dat een bestaande staart een "Btw laag"-regel heeft. Bestaande
 * begrotingen van vóór het lage tarief krijgen er bij het laden één bij
 * (9%, zonder grondslag → draagt € 0 bij tot de grondslag is ingevuld).
 * Muteert niets: retourneert dezelfde array of een nieuwe met de extra rij.
 */
export function ensureBtwLaagItem(items: CostItem[]): CostItem[] {
  const hasStaart = items.some((i) => i.rowType?.startsWith('staart_'));
  if (!hasStaart) return items;
  if (items.some((i) => i.rowType === 'staart_btw_laag')) return items;
  const btwIdx = items.findIndex((i) => i.rowType === 'staart_btw');
  if (btwIdx < 0) return items;
  const btw = items[btwIdx];
  const laag = makeStaartItem('staart_btw_laag', 'Btw laag:', '9', btw.sortOrder);
  // Direct vóór de hoog-regel; alles vanaf de hoog-regel schuift één plek op.
  return [
    ...items.slice(0, btwIdx),
    laag,
    ...items.slice(btwIdx).map((i) =>
      i.rowType?.startsWith('staart_') ? { ...i, sortOrder: i.sortOrder + 1 } : i,
    ),
  ];
}
