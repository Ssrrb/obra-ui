/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

import Decimal from 'decimal.js';
import { DECIMAL_PATTERN, DECIMAL_PRECISION, type DecimalString } from './contracts';
import { BudgetValidationError } from './errors';

/**
 * The only arithmetic of the engine: an isolated decimal.js constructor with
 * 80 significant digits and HALF_UP. The global Decimal config is untouched.
 * `new Dec(text)` keeps every digit of `text`; precision applies to results.
 */
export const Dec = Decimal.clone({ precision: DECIMAL_PRECISION, rounding: Decimal.ROUND_HALF_UP });
export type Dec = Decimal;

export const MAX_INTEGER_DIGITS = 24;
export const MAX_FRACTION_DIGITS = 12;

/** Plain decimal text, lenient about redundant zeros: `1.50`, `-0`, `.5`, `5.`. */
const PLAIN = /^-?(\d+\.?\d*|\.\d+)$/;
/** A JSON number literal, which may carry an exponent. */
const LITERAL = /^-?\d+(\.\d+)?([eE][+-]?\d+)?$/;

const ZERO = new Dec(0);

/** Canonical text of `value` if it fits 24 integer and 12 fraction digits, else null. Never rounds. */
const fit = (value: Decimal): DecimalString | null => {
	if (!value.isFinite()) {
		return null;
	}
	if (value.isZero()) {
		return '0';
	}
	// Bounds first, so a huge exponent never expands into a huge string.
	if (value.e >= MAX_INTEGER_DIGITS || value.decimalPlaces() > MAX_FRACTION_DIGITS) {
		return null;
	}
	const text = value.toFixed();
	return DECIMAL_PATTERN.test(text) ? text : null;
};

/**
 * Normalizes decimal text to its canonical form (DECIMAL_PATTERN): `.` as
 * separator, no redundant zeros, no `-0`. Returns null for anything else:
 * exponents (unless `exponent`), commas, thousands separators, signs other
 * than a leading `-`, or more than 24 integer / 12 fraction digits.
 */
export const normalizeDecimal = (text: string, { exponent = false }: { readonly exponent?: boolean } = {}): DecimalString | null =>
	(exponent ? LITERAL : PLAIN).test(text) ? fit(new Dec(text)) : null;

/** Like normalizeDecimal for an untrusted value; throws BudgetValidationError at `path`. */
export const parseDecimal = (value: unknown, path: string): DecimalString => {
	if (typeof value !== 'string' || !PLAIN.test(value)) {
		throw new BudgetValidationError(path, 'must be a decimal string such as "1234.5"');
	}
	const out = fit(new Dec(value));
	if (out === null) {
		throw new BudgetValidationError(path, `must have at most ${MAX_INTEGER_DIGITS} integer and ${MAX_FRACTION_DIGITS} fraction digits`);
	}
	return out;
};

/** A stored decimal as a Decimal; null and absent read as zero (upstream `?? 0`). */
export const decimalOf = (value: DecimalString | null | undefined): Decimal => value === null || value === undefined ? ZERO : new Dec(value);

/**
 * Canonical text of a computed value, rounded HALF_UP to the 12 fraction
 * digits a DecimalString can hold. Throws BudgetValidationError at `path`
 * when the integer part exceeds 24 digits.
 */
export const toDecimalString = (value: Decimal, path = 'value'): DecimalString => {
	const out = fit(value.toDecimalPlaces(MAX_FRACTION_DIGITS));
	if (out === null) {
		throw new BudgetValidationError(path, `exceeds ${MAX_INTEGER_DIGITS} integer digits`);
	}
	return out;
};

/** `value` rounded HALF_UP to `scale` fraction digits, as canonical text. */
export const quantizeDecimal = (value: DecimalString, scale: number): DecimalString => toDecimalString(new Dec(value).toDecimalPlaces(scale));
