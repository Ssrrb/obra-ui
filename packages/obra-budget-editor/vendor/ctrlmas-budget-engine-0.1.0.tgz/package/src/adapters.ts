/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

/**
 * Adapters between schema 2 (money as DecimalString) and number-based
 * documents: schema 1 budgets and native OpenCalc `.ocs`/`.ifcCalc` files.
 */

import { isLosslessNumber, parse } from 'lossless-json';
import { normalizeDecimal } from './decimal';
import { BudgetValidationError } from './errors';
import { setOwn } from './items';
import { getKostprijs, recalculateItems } from './opencalc/calculation/calculator';
import type { CostItem, ProjectFile } from './opencalc/types/costModel';
import { isRecord, parseDocument, visitDocumentDecimals, type DecimalVisit } from './parse';

const literal = (text: string, path: string): string => {
	const out = normalizeDecimal(text, { exponent: true });
	if (out === null) {
		throw new BudgetValidationError(path, `${text} does not fit 24 integer and 12 fraction digits; it is not rounded, correct it in the source file`);
	}
	return out;
};

/** Money value of a number document: the JSON literal, a number's shortest round-trip text, or decimal text. */
const upgradeValue: DecimalVisit = (value, path) => {
	if (value === null || value === undefined) {
		return value;
	}
	if (isLosslessNumber(value)) {
		return literal(value.value, path);
	}
	if (typeof value === 'number') {
		if (!Number.isFinite(value)) {
			throw new BudgetValidationError(path, 'must be a finite number');
		}
		return literal(String(value), path);
	}
	if (typeof value === 'string') {
		return literal(value, path);
	}
	throw new BudgetValidationError(path, 'must be a number, a decimal string or null');
};

/** Replaces, in place, every remaining LosslessNumber (non-money fields) with a number. */
const plainNumbers = (value: unknown): unknown => {
	if (isLosslessNumber(value)) {
		return Number(value.value);
	}
	if (Array.isArray(value)) {
		value.forEach((entry, i) => {
			value[i] = plainNumbers(entry);
		});
	} else if (isRecord(value)) {
		for (const key of Object.keys(value)) {
			setOwn(value, key, plainNumbers(value[key]));
		}
	}
	return value;
};

/**
 * Derived money (unitPrice, total, breakdowns, snapshot totals) is recomputed
 * instead of converted, so float noise such as 90.00000000000001 in values
 * upstream computed never blocks an upgrade.
 */
const resetDerived = (items: unknown): void => {
	if (Array.isArray(items)) {
		for (const item of items) {
			if (isRecord(item)) {
				delete item.staartItemBreakdown;
				item.unitPrice = '0';
				item.total = '0';
			}
		}
	}
};

const upgrade = (value: unknown): ProjectFile => {
	if (!isRecord(value)) {
		throw new BudgetValidationError('', 'must be an object');
	}
	resetDerived(value.items);
	if (Array.isArray(value.snapshots)) {
		for (const snapshot of value.snapshots) {
			if (isRecord(snapshot)) {
				resetDerived(snapshot.items);
				snapshot.totaalExclBtw = '0';
			}
		}
	}
	visitDocumentDecimals(value, upgradeValue);
	const doc = parseDocument(plainNumbers(value));
	doc.items = recalculateItems(doc.items);
	for (const snapshot of doc.snapshots ?? []) {
		if (Array.isArray(snapshot.items)) {
			snapshot.items = recalculateItems(snapshot.items as CostItem[]);
			// Upstream versionSlice: sum of the top-level totals.
			snapshot.totaalExclBtw = getKostprijs(snapshot.items);
		}
	}
	return doc;
};

/**
 * Converts an already-parsed schema 1 / native OpenCalc document (money as
 * numbers) to schema 2. Each money number becomes its shortest round-trip
 * text (`String(n)`), so a value JSON.parse already rounded stays rounded;
 * prefer upgradeDocumentText when the raw JSON is available. Decimal strings
 * are normalized, so upgrading a schema 2 document is a no-op. A value with
 * more than 24 integer or 12 fraction digits throws BudgetValidationError;
 * nothing is rounded. Derived fields are recalculated. The input is not
 * modified.
 */
export const upgradeDocument = (value: unknown): ProjectFile => upgrade(structuredClone(value));

/**
 * Converts raw JSON text of a schema 1 / native OpenCalc document to schema
 * 2, reading every money value from its original JSON literal with
 * lossless-json (`0.1` stays 0.1, `1234.5600` becomes 1234.56 and
 * `123456789012345678.123456` keeps every digit). Other numbers become
 * JavaScript numbers. Same limits as upgradeDocument.
 */
export const upgradeDocumentText = (text: string): ProjectFile => {
	let value: unknown;
	try {
		value = parse(text);
	} catch (error) {
		throw new BudgetValidationError('', `is not valid JSON: ${error instanceof Error ? error.message : String(error)}`);
	}
	return upgrade(value);
};

/**
 * A copy of `budget` with every money field written back as a number, for
 * native OpenCalc files. Precision limit: a JavaScript number holds 15 to 17
 * significant digits, so values with more (for example 24 integer digits, or
 * `123456789012345678.123456`) are rounded to the nearest double here.
 * ivaRate and ivaMode are kept as extra keys.
 */
export const downgradeForExport = (budget: ProjectFile): unknown => {
	const copy = structuredClone(budget) as unknown as Record<string, unknown>;
	visitDocumentDecimals(copy, value => typeof value === 'string' ? Number(value) : value);
	return copy;
};
