/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

/**
 * Public contracts of the Presupuestos slice. The orchestrator owns this file:
 * the engine, the API and the ctrl host consume it and never redefine it.
 *
 * The canonical document is the OpenCalc `ProjectFile` (src/opencalc/types).
 * Item ids are identity; grid indices are not. Revision, authors and dates
 * are fixed by the server.
 */

import type { CostItem, ProjectFile } from './opencalc/types/costModel';

/**
 * Version of the integration envelope around the OpenCalc document.
 * 2: every money value is a canonical decimal string (see DecimalString).
 */
export const BUDGET_SCHEMA_VERSION = 2;

/** Version of the calculation: OpenCalc upstream plus the ctrl adaptation. */
export const ENGINE_VERSION = '0.13.0+ctrl.2';

/**
 * A decimal as canonical text: `.` as separator, no thousands separator, no
 * redundant zeros, no `-0`, no exponent. At most 24 integer and 12 fraction
 * digits; anything longer is rejected, never rounded silently. Matches
 * DECIMAL_PATTERN. Comparisons and hashes use this exact text.
 */
export type DecimalString = string;
export const DECIMAL_PATTERN = /^(?!-0$)-?(0|[1-9]\d{0,23})(\.\d{0,11}[1-9])?$/;

/** decimal.js configuration shared by editor, host and server. */
export const DECIMAL_PRECISION = 80;

/**
 * Money policy (identical in editor, server, print and export):
 * - a line keeps full precision internally; its amount is quantized to two
 *   decimals HALF_UP;
 * - each markup (staart) is quantized to two decimals HALF_UP after applying
 *   it to its declared base;
 * - IVA is computed per rate group on the sum of quantized amounts and
 *   quantized to two decimals HALF_UP; markups are split across rate groups
 *   pro rata of their direct cost; with IVA included, the base is derived
 *   from the gross amount and the tax is the difference, so base + tax equals
 *   the gross amount exactly;
 * - the contractual total sums quantized amounts; the contractual adjustment
 *   to an integer (PYG) or a cent (USD) is shown separately, HALF_UP.
 */
export const LINE_SCALE = 2;
export const CONTRACT_SCALE: Record<BudgetCurrency, number> = { PYG: 0, USD: 2 };

/** IVA rate of a row; children inherit from their parent; null inherits. Root default: '10'. */
export type IvaRate = 'exento' | '5' | '10';
/** Whether the prices of a budget include IVA. Stored as `schedule.ivaMode`. */
export type IvaMode = 'incluido' | 'separado';

/**
 * Money fields that schema 2 stores as DecimalString | null. Indices,
 * revisions and visual properties stay `number`.
 */
export const DECIMAL_ITEM_FIELDS = ['quantity', 'materialPrice', 'laborPrice', 'unitPrice', 'total', 'staartPercentage', 'normQuantity', 'normFactor', 'normDivisor', 'normUnitPrice', 'staartDoelbedrag', 'staartVastBedrag', 'staartAfrondingStap', 'staartBtwBasis'] as const;
export const DECIMAL_SCHEDULE_FIELDS = ['uitvoeringskosten', 'algemeneKosten', 'winstRisico'] as const;
/** Also decimal: every value of `schedule.tarieven`, StaartItemBreakdown and StagartRow amounts, ResourceLibraryItem.defaultUnitPrice. */

/**
 * IVA in schema 2 comes only from `item.ivaRate` and `schedule.ivaMode`
 * (default 'separado'). Upstream Dutch VAT rows (`staart_btw`,
 * `staart_btw_laag`) and `btwTarief` are kept in the document but contribute
 * zero and produce a warning; the engine never infers a tax treatment.
 */
export interface BudgetTotals {
	readonly currency: BudgetCurrency;
	/** Sum of quantized line amounts of the direct cost. */
	readonly direct: DecimalString;
	/** Each markup row with its declared base and quantized amount. */
	readonly markups: readonly { readonly id: string; readonly base: DecimalString; readonly amount: DecimalString }[];
	/** One entry per IVA rate present: taxable base and quantized tax. */
	readonly iva: readonly { readonly rate: IvaRate; readonly base: DecimalString; readonly tax: DecimalString }[];
	/** Sum of quantized amounts, before the contractual adjustment. */
	readonly total: DecimalString;
	/** Contractual adjustment to CONTRACT_SCALE, shown separately. */
	readonly adjustment: DecimalString;
	/** total + adjustment. */
	readonly contractTotal: DecimalString;
	readonly warnings: readonly string[];
}

export type BudgetCurrency = 'PYG' | 'USD';

/**
 * Item fields the calculator derives. Commands never carry them; the server
 * recomputes them after every accepted batch.
 */
export const DERIVED_ITEM_FIELDS = ['unitPrice', 'total', 'depth', 'sortOrder', 'nr', 'staartItemBreakdown', 'history'] as const;
export type DerivedItemField = typeof DERIVED_ITEM_FIELDS[number];

/** An item as commands carry it: without the fields the calculator derives. */
export type ItemInput = Omit<CostItem, DerivedItemField>;

/** Top-level document keys that `doc.set` may replace as a whole value. */
export const DOCUMENT_VALUE_KEYS = ['companyInfo', 'resourceLibrary', 'spreadsheets', 'subSheets', 'offerte', 'brandSlug'] as const;
export type DocumentValueKey = typeof DOCUMENT_VALUE_KEYS[number];

/** Position of an item: its parent and the sibling it follows (null = first). */
export interface ItemPosition {
	readonly parentId: string | null;
	readonly afterId: string | null;
}

/** A JSON value as stored in the document. Compared by canonical JSON. */
export type JsonValue = null | boolean | number | string | JsonValue[] | { [key: string]: JsonValue };

/**
 * One typed command. Every command carries the value its author saw (`base`)
 * as precondition. A command applies if the current value equals `base`, or
 * already equals the proposed value. Otherwise it is a conflict.
 *
 * Preconditions are checked against the document before the batch; commands
 * then apply in order. `item.move` checks only `base.parentId`: sibling order
 * is last writer wins, so another member's insertion is not a conflict.
 * `afterId` is the target anchor and must exist under the target parent when
 * the command applies. `item.delete` checks every non-derived field of
 * `base` except the position. `item.set` never targets `id`, `parentId` or a
 * derived field; a value of `undefined` removes the key.
 */
export type BudgetCommand =
	| { readonly type: 'item.set'; readonly id: string; readonly field: string; readonly base: JsonValue | undefined; readonly value: JsonValue | undefined }
	| { readonly type: 'item.insert'; readonly item: ItemInput; readonly position: ItemPosition }
	| { readonly type: 'item.delete'; readonly id: string; readonly base: ItemInput }
	| { readonly type: 'item.move'; readonly id: string; readonly base: ItemPosition; readonly value: ItemPosition }
	| { readonly type: 'schedule.set'; readonly field: string; readonly base: JsonValue | undefined; readonly value: JsonValue | undefined }
	| { readonly type: 'doc.set'; readonly key: DocumentValueKey; readonly base: JsonValue | undefined; readonly value: JsonValue | undefined };

/** Client intent. A retry keeps `mutationId` and the exact content. */
export interface BudgetCommandBatch {
	readonly mutationId: string;
	readonly baseRevision: number;
	readonly commands: readonly BudgetCommand[];
}

/** Why one command of a batch did not apply. The batch applies all or nothing. */
export interface BudgetConflict {
	readonly index: number;
	readonly code: 'precondition_failed' | 'item_missing' | 'item_exists' | 'parent_missing' | 'anchor_missing' | 'cycle' | 'orphan';
	readonly command: BudgetCommand;
	/** The current value the precondition was checked against, if any. */
	readonly current?: JsonValue;
}

export type ApplyResult =
	| { readonly ok: true; readonly document: ProjectFile }
	| { readonly ok: false; readonly conflicts: readonly BudgetConflict[] };

/** GET/POST /v1/organizations/:orgId/projects/:projectId/budget */
export interface BudgetSnapshot {
	readonly orgId: string;
	readonly projectId: string;
	readonly budgetId: string;
	readonly revision: number;
	readonly schemaVersion: number;
	readonly engineVersion: string;
	readonly currency: BudgetCurrency;
	readonly deleted: boolean;
	readonly document: ProjectFile;
}

/** One accepted batch, as the server recorded it. */
export interface BudgetChange {
	readonly revision: number;
	readonly mutationId: string;
	readonly actorId: string;
	readonly commands: readonly BudgetCommand[];
}

/** POST .../budget/commands → 200. A replay of the same batch returns the same body. */
export interface BudgetCommandResult {
	readonly mutationId: string;
	readonly fromRevision: number;
	readonly revision: number;
	readonly replayed: boolean;
}

/** GET .../budget/changes?after=N&limit=M (limit 1..200, default 100), ascending. */
export interface BudgetChangePage {
	readonly changes: readonly BudgetChange[];
	readonly revision: number;
	readonly hasMore: boolean;
}

/**
 * Host ↔ webview bridge, protocol version 1. The host binds organization,
 * project and token; the webview never sees them and cannot choose them.
 */
export const BRIDGE_PROTOCOL_VERSION = 1;

export type BudgetStatus = 'loading' | 'saved' | 'pending' | 'reconnecting' | 'conflict' | 'revoked' | 'error';

/**
 * `seq` orders the documents the host posts. `changed` names the last `seq`
 * the webview applied, so the host takes only the user's edits relative to
 * that document and never reverts a remote change still in flight.
 */
export type HostToWebview =
	| { readonly v: 1; readonly type: 'load'; readonly seq: number; readonly revision: number; readonly document: ProjectFile; readonly title: string }
	| { readonly v: 1; readonly type: 'remote'; readonly seq: number; readonly revision: number; readonly document: ProjectFile }
	| { readonly v: 1; readonly type: 'status'; readonly status: BudgetStatus; readonly message?: string };

export type WebviewToHost =
	| { readonly v: 1; readonly type: 'ready' }
	| { readonly v: 1; readonly type: 'changed'; readonly seq: number; readonly document: ProjectFile };

/**
 * Engine surface (implemented in src/index.ts, consumed by API and host):
 *
 * - `applyCommands(document, commands): ApplyResult` applies all commands or
 *   none, validates the tree (no orphan, no cycle) and recalculates.
 * - `diffDocuments(base, next): BudgetCommand[]` returns the commands that
 *   turn `base` into `next`, ignoring DERIVED_ITEM_FIELDS. Equal inputs give [].
 * - `createEmptyDocument({ name, currency }): ProjectFile`.
 * - `parseDocument(value: unknown): ProjectFile` validates the shape at a
 *   trust boundary and throws a typed error.
 * - `parseCommandBatch(value: unknown): BudgetCommandBatch` validates a batch
 *   at a trust boundary: UUID mutationId, integer baseRevision >= 0, one to
 *   5,000 known commands, no derived field. Throws a typed error.
 * - `computeTotals(document, currency): BudgetTotals` applies the money policy.
 * - `canonicalJson(value): string` sorts keys; it backs equality and hashes.
 */
export interface BudgetEngine {
	applyCommands(document: ProjectFile, commands: readonly BudgetCommand[]): ApplyResult;
	diffDocuments(base: ProjectFile, next: ProjectFile): BudgetCommand[];
	createEmptyDocument(input: { readonly name: string; readonly currency: BudgetCurrency }): ProjectFile;
	parseDocument(value: unknown): ProjectFile;
	parseCommandBatch(value: unknown): BudgetCommandBatch;
	computeTotals(document: ProjectFile, currency: BudgetCurrency): BudgetTotals;
	canonicalJson(value: unknown): string;
}
