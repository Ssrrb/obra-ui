/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

import type { BudgetCurrency, BudgetEngine } from './contracts';
import { applyCommands } from './apply';
import { canonicalJson } from './canonical';
import { diffDocuments } from './diff';
import { parseCommandBatch, parseDocument } from './parse';
import { computeTotals } from './totals';
import { createDefaultProjectProperties, type ProjectFile } from './opencalc/types/costModel';

export * from './contracts';
export type * from './opencalc/types/costModel';
export { applyCommands, canonicalJson, computeTotals, diffDocuments, parseCommandBatch, parseDocument };
export { BudgetValidationError } from './errors';
export { Dec, MAX_FRACTION_DIGITS, MAX_INTEGER_DIGITS, decimalOf, normalizeDecimal, parseDecimal, quantizeDecimal, toDecimalString } from './decimal';
export { evaluateDecimalExpression, parseDecimalInput, type NumberLocale } from './expression';
export { downgradeForExport, upgradeDocument, upgradeDocumentText } from './adapters';

/** Upstream `.ifcCalc` format version (fileService FILE_FORMAT_VERSION). */
const FILE_FORMAT_VERSION = '2.2.0';

/** Upstream defaultBudget `generateIfcGuid`: 22 chars of the IFC alphabet. */
const generateIfcGuid = (): string => {
	const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$';
	let guid = '';
	for (let i = 0; i < 22; i++) {
		guid += chars[Math.floor(Math.random() * 64)];
	}
	return guid;
};

/**
 * A new schema 2 project as upstream writes it (createDefaultSchedule +
 * createProjectFile), with our name and currency, IVA separado and no
 * items: upstream's default staart rows are left to the product layer.
 */
export const createEmptyDocument = ({ name, currency }: { readonly name: string; readonly currency: BudgetCurrency }): ProjectFile => {
	const now = new Date().toISOString();
	return {
		version: FILE_FORMAT_VERSION,
		schedule: {
			id: crypto.randomUUID(),
			name,
			description: '',
			status: 'DRAFT',
			predefinedType: 'ESTIMATE',
			currency,
			projectName: '',
			projectNumber: '',
			client: '',
			author: '',
			ifcGuid: generateIfcGuid(),
			// Upstream derives these legacy scalars from its default staart rows (ABK 6, AK OA 9, winst 5).
			uitvoeringskosten: '6',
			algemeneKosten: '9',
			winstRisico: '5',
			ivaMode: 'separado',
			projectProperties: createDefaultProjectProperties(),
		},
		items: [],
		resourceLibrary: [],
		companyInfo: {
			name: '',
			postalAddress: '',
			postalCity: '',
			visitAddress: '',
			visitCity: '',
			phone: '',
			fax: '',
			email: '',
			logoLeft: '',
			logoRight: '',
		},
		spreadsheets: { sheets: [], activeSheetId: null },
		createdAt: now,
		modifiedAt: now,
	};
};

export const budgetEngine: BudgetEngine = {
	applyCommands,
	diffDocuments,
	createEmptyDocument,
	parseDocument,
	parseCommandBatch,
	computeTotals,
	canonicalJson,
};
