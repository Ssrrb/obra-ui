/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

import { DOCUMENT_VALUE_KEYS, type BudgetCommand, type JsonValue } from './contracts';
import { sameJson } from './canonical';
import { getOwn, positionsOf, stripDerived } from './items';
import { normalizeItemOrder } from './opencalc/calculation/calculator';
import type { CostItem, ProjectFile } from './opencalc/types/costModel';

const keysOf = (...records: object[]): string[] => [...new Set(records.flatMap(record => Object.keys(record)))].sort();

/** Canonical order (depth-first, staart last) on shallow copies; input untouched. */
const ordered = (items: readonly CostItem[]): CostItem[] => normalizeItemOrder(items.map(item => ({ ...item })));

/** Elements of `seq` forming one longest strictly increasing run of `rank`. */
const longestIncreasing = <T>(seq: readonly T[], rank: (value: T) => number): T[] => {
	const tails: number[] = [];
	const previous: number[] = [];
	for (let i = 0; i < seq.length; i++) {
		const r = rank(seq[i]!);
		let lo = 0;
		let hi = tails.length;
		while (lo < hi) {
			const mid = (lo + hi) >> 1;
			if (rank(seq[tails[mid]!]!) < r) {
				lo = mid + 1;
			} else {
				hi = mid;
			}
		}
		previous[i] = lo > 0 ? tails[lo - 1]! : -1;
		tails[lo] = i;
	}
	const out: T[] = [];
	for (let i = tails.length > 0 ? tails[tails.length - 1]! : -1; i >= 0; i = previous[i]!) {
		out.push(seq[i]!);
	}
	return out.reverse();
};

/**
 * Commands that turn `base` into `next`, ignoring derived item fields.
 * Order: doc.set, schedule.set, item.delete (children first), item.set, then
 * item.insert and item.move in the canonical order of `next`, so parents and
 * anchors exist before use. Items that keep their parent and their relative
 * order (a longest increasing subsequence) are not moved.
 */
export const diffDocuments = (base: ProjectFile, next: ProjectFile): BudgetCommand[] => {
	const commands: BudgetCommand[] = [];

	for (const key of DOCUMENT_VALUE_KEYS) {
		const before = getOwn(base, key);
		const after = getOwn(next, key);
		if (!sameJson(before, after)) {
			commands.push({ type: 'doc.set', key, base: before as JsonValue | undefined, value: after as JsonValue | undefined });
		}
	}

	for (const field of keysOf(base.schedule, next.schedule)) {
		const before = getOwn(base.schedule, field);
		const after = getOwn(next.schedule, field);
		if (!sameJson(before, after)) {
			commands.push({ type: 'schedule.set', field, base: before as JsonValue | undefined, value: after as JsonValue | undefined });
		}
	}

	const baseItems = ordered(base.items);
	const nextItems = ordered(next.items);
	const baseById = new Map(baseItems.map(item => [item.id, item]));
	const nextById = new Map(nextItems.map(item => [item.id, item]));
	const basePositions = positionsOf(baseItems);
	const nextPositions = positionsOf(nextItems);

	const depthOf = (item: CostItem): number => {
		const seen = new Set<string>([item.id]);
		let depth = 0;
		for (let parent = baseById.get(item.parentId ?? ''); parent && !seen.has(parent.id); parent = baseById.get(parent.parentId ?? '')) {
			seen.add(parent.id);
			depth++;
		}
		return depth;
	};
	const removed = baseItems.filter(item => !nextById.has(item.id)).map(item => ({ item, depth: depthOf(item) }));
	removed.sort((a, b) => b.depth - a.depth);
	for (const { item } of removed) {
		commands.push({ type: 'item.delete', id: item.id, base: stripDerived(item) });
	}

	for (const item of nextItems) {
		const before = baseById.get(item.id);
		if (!before) {
			continue;
		}
		const a = stripDerived(before);
		const b = stripDerived(item);
		for (const field of keysOf(a, b)) {
			if (field === 'id' || field === 'parentId') {
				continue;
			}
			const from = getOwn(a, field);
			const to = getOwn(b, field);
			if (!sameJson(from, to)) {
				commands.push({ type: 'item.set', id: item.id, field, base: from as JsonValue | undefined, value: to as JsonValue | undefined });
			}
		}
	}

	const baseRank = new Map<string, number>();
	const baseSiblingCount = new Map<string | null, number>();
	for (const item of baseItems) {
		const count = baseSiblingCount.get(item.parentId) ?? 0;
		baseRank.set(item.id, count);
		baseSiblingCount.set(item.parentId, count + 1);
	}
	const nextChildren = new Map<string | null, CostItem[]>();
	for (const item of nextItems) {
		const list = nextChildren.get(item.parentId);
		if (list) {
			list.push(item);
		} else {
			nextChildren.set(item.parentId, [item]);
		}
	}
	const stable = new Set<string>();
	for (const [parentId, children] of nextChildren) {
		const kept = children.filter(child => baseById.get(child.id)?.parentId === parentId);
		for (const child of longestIncreasing(kept, child => baseRank.get(child.id)!)) {
			stable.add(child.id);
		}
	}

	for (const item of nextItems) {
		const position = nextPositions.get(item.id)!;
		if (!baseById.has(item.id)) {
			commands.push({ type: 'item.insert', item: stripDerived(item), position });
		} else if (!stable.has(item.id)) {
			commands.push({ type: 'item.move', id: item.id, base: basePositions.get(item.id)!, value: position });
		}
	}

	return commands;
};
