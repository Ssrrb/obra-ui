/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

import { DECIMAL_ITEM_FIELDS, DECIMAL_SCHEDULE_FIELDS, DOCUMENT_VALUE_KEYS, type BudgetCommandBatch } from './contracts';
import { parseDecimal } from './decimal';
import { BudgetValidationError } from './errors';
import { DERIVED, setOwn } from './items';
import type { ProjectFile } from './opencalc/types/costModel';

export { BudgetValidationError };

export const MAX_ITEMS = 10_000;
export const MAX_COMMANDS = 5_000;

/** Visual item fields stored as numbers: finite number or null. */
const NUMERIC_ITEM_FIELDS = new Set(['textSize']);
const DECIMAL_ITEM_KEYS = new Set<string>(DECIMAL_ITEM_FIELDS);
const BREAKDOWN_KEYS = ['loon', 'materiaal', 'materieel', 'stelpost', 'onderaanneming', 'bedrag', 'subtotaal', 'totaal'] as const;
const STAART_ROW_KEYS = ['percentage', ...BREAKDOWN_KEYS] as const;
const IVA_RATES = new Set<unknown>([null, 'exento', '5', '10']);
const IVA_MODES = new Set<unknown>(['incluido', 'separado']);
const DOCUMENT_KEYS = new Set<string>(DOCUMENT_VALUE_KEYS);
const COMMAND_TYPES = new Set(['item.set', 'item.insert', 'item.delete', 'item.move', 'schedule.set', 'doc.set']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type Obj = Record<string, unknown>;

const fail = (path: string, message: string): never => {
	throw new BudgetValidationError(path, message);
};

export const isRecord = (value: unknown): value is Obj => value !== null && typeof value === 'object' && !Array.isArray(value);

const obj = (value: unknown, path: string): Obj => isRecord(value) ? value : fail(path, 'must be an object');

const str = (value: unknown, path: string): string => typeof value === 'string' && value !== '' ? value : fail(path, 'must be a non-empty string');

const nullableStr = (value: unknown, path: string): string | null => value === null ? null : str(value, path);

const numeric = (value: unknown, path: string): void => {
	if (value !== undefined && value !== null && !(typeof value === 'number' && Number.isFinite(value))) {
		fail(path, 'must be a finite number or null');
	}
};

const jsonValue = (value: unknown, path: string): void => {
	if (value === undefined || value === null || typeof value === 'string' || typeof value === 'boolean') {
		return;
	}
	if (typeof value === 'number') {
		return Number.isFinite(value) ? undefined : fail(path, 'must be a finite number');
	}
	if (Array.isArray(value)) {
		value.forEach((entry, i) => jsonValue(entry, `${path}[${i}]`));
		return;
	}
	if (isRecord(value)) {
		for (const key of Object.keys(value)) {
			jsonValue(value[key], `${path}.${key}`);
		}
		return;
	}
	fail(path, 'must be a JSON value');
};

/** Maps one decimal field; `path` names it. Returns the value to store (undefined removes it). */
export type DecimalVisit = (value: unknown, path: string) => unknown;

const visitKeys = (record: unknown, keys: readonly string[], path: string, visit: DecimalVisit): void => {
	if (!isRecord(record)) {
		return;
	}
	for (const key of keys) {
		if (Object.hasOwn(record, key)) {
			setOwn(record, key, visit(record[key], `${path}.${key}`));
		}
	}
};

const visitItem = (item: unknown, path: string, visit: DecimalVisit): void => {
	visitKeys(item, DECIMAL_ITEM_FIELDS, path, visit);
	if (isRecord(item)) {
		visitKeys(item.staartItemBreakdown, BREAKDOWN_KEYS, `${path}.staartItemBreakdown`, visit);
	}
};

const visitSchedule = (schedule: unknown, path: string, visit: DecimalVisit): void => {
	if (!isRecord(schedule)) {
		return;
	}
	visitKeys(schedule, DECIMAL_SCHEDULE_FIELDS, path, visit);
	if (isRecord(schedule.tarieven)) {
		visitKeys(schedule.tarieven, Object.keys(schedule.tarieven), `${path}.tarieven`, visit);
	}
	if (Array.isArray(schedule.staartRows)) {
		schedule.staartRows.forEach((row, i) => visitKeys(row, STAART_ROW_KEYS, `${path}.staartRows[${i}]`, visit));
	}
};

const visitEach = (list: unknown, path: string, each: (entry: unknown, path: string) => void): void => {
	if (Array.isArray(list)) {
		list.forEach((entry, i) => each(entry, `${path}[${i}]`));
	}
};

/**
 * Applies `visit` in place to every money field of a (possibly partial)
 * document that schema 2 stores as DecimalString: DECIMAL_ITEM_FIELDS and
 * staartItemBreakdown of items, DECIMAL_SCHEDULE_FIELDS, tarieven and
 * staartRows of the schedule, resourceLibrary defaultUnitPrice, and the same
 * inside snapshots (plus their totaalExclBtw). Only present keys are visited.
 */
export const visitDocumentDecimals = (doc: Obj, visit: DecimalVisit): void => {
	visitSchedule(doc.schedule, 'schedule', visit);
	visitEach(doc.items, 'items', (entry, path) => visitItem(entry, path, visit));
	visitEach(doc.resourceLibrary, 'resourceLibrary', (entry, path) => visitKeys(entry, ['defaultUnitPrice'], path, visit));
	visitEach(doc.snapshots, 'snapshots', (snapshot, path) => {
		visitKeys(snapshot, ['totaalExclBtw'], path, visit);
		if (isRecord(snapshot)) {
			visitSchedule(snapshot.schedule, `${path}.schedule`, visit);
			visitEach(snapshot.items, `${path}.items`, (entry, itemPath) => visitItem(entry, itemPath, visit));
		}
	});
};

/** Canonical decimal text, null or absent; anything else is rejected. */
const canonical: DecimalVisit = (value, path) => value === undefined || value === null ? value : parseDecimal(value, path);

/** Runs `visit` on a single command value, as if it sat at `wrap` in a document; errors point at `path`. */
const normalizeValue = (value: unknown, path: string, wrap: (value: unknown) => Obj, read: (doc: Obj) => unknown): unknown => {
	if (value === undefined) {
		return undefined;
	}
	const doc = wrap(value);
	visitDocumentDecimals(doc, (entry, inner) => {
		try {
			return canonical(entry, inner);
		} catch {
			return fail(path, 'must hold canonical decimal strings');
		}
	});
	return read(doc);
};

const ivaRate = (value: unknown, path: string): void => {
	if (value !== undefined && !IVA_RATES.has(value)) {
		fail(path, 'must be "exento", "5", "10" or null');
	}
};

const ivaMode = (value: unknown, path: string): void => {
	if (value !== undefined && !IVA_MODES.has(value)) {
		fail(path, 'must be "incluido" or "separado"');
	}
};

const item = (value: unknown, path: string, allowDerived: boolean): Obj => {
	const it = obj(value, path);
	str(it.id, `${path}.id`);
	nullableStr(it.parentId, `${path}.parentId`);
	str(it.rowType, `${path}.rowType`);
	for (const key of Object.keys(it)) {
		if (!allowDerived && DERIVED.has(key)) {
			fail(`${path}.${key}`, 'is derived and cannot be sent');
		} else if (NUMERIC_ITEM_FIELDS.has(key)) {
			numeric(it[key], `${path}.${key}`);
		}
	}
	ivaRate(it.ivaRate, `${path}.ivaRate`);
	visitItem(it, path, canonical);
	return it;
};

const position = (value: unknown, path: string): void => {
	const pos = obj(value, path);
	nullableStr(pos.parentId, `${path}.parentId`);
	nullableStr(pos.afterId, `${path}.afterId`);
};

/**
 * Validates a schema 2 OpenCalc ProjectFile; unknown fields are kept.
 * Every money field must be decimal text (or null) and is normalized in
 * place to its canonical form; numbers are rejected (see upgradeDocument).
 * Returns the input.
 */
export const parseDocument = (value: unknown): ProjectFile => {
	const doc = obj(value, '');
	ivaMode(obj(doc.schedule, 'schedule').ivaMode, 'schedule.ivaMode');
	if (!Array.isArray(doc.items)) {
		return fail('items', 'must be an array');
	}
	if (doc.items.length > MAX_ITEMS) {
		fail('items', `must have at most ${MAX_ITEMS} items`);
	}
	const ids = new Set<string>();
	doc.items.forEach((entry, i) => {
		const it = item(entry, `items[${i}]`, true);
		if (ids.has(it.id as string)) {
			fail(`items[${i}].id`, 'is duplicated');
		}
		ids.add(it.id as string);
	});
	visitDocumentDecimals(doc, canonical);
	return value as ProjectFile;
};

const command = (value: unknown, path: string): void => {
	const cmd = obj(value, path);
	if (typeof cmd.type !== 'string' || !COMMAND_TYPES.has(cmd.type)) {
		fail(`${path}.type`, 'is not a known command');
	}
	switch (cmd.type) {
		case 'item.set': {
			str(cmd.id, `${path}.id`);
			const field = str(cmd.field, `${path}.field`);
			if (field === 'id' || field === 'parentId' || DERIVED.has(field)) {
				fail(`${path}.field`, `cannot set ${field}`);
			}
			for (const key of ['base', 'value'] as const) {
				const at = `${path}.${key}`;
				if (DECIMAL_ITEM_KEYS.has(field)) {
					setOwn(cmd, key, normalizeValue(cmd[key], at, entry => ({ items: [{ [field]: entry }] }), doc => (doc.items as Obj[])[0]![field]));
				} else if (field === 'ivaRate') {
					ivaRate(cmd[key], at);
				} else {
					(NUMERIC_ITEM_FIELDS.has(field) ? numeric : jsonValue)(cmd[key], at);
				}
			}
			break;
		}
		case 'item.insert':
			item(cmd.item, `${path}.item`, false);
			position(cmd.position, `${path}.position`);
			break;
		case 'item.delete': {
			const id = str(cmd.id, `${path}.id`);
			if (item(cmd.base, `${path}.base`, false).id !== id) {
				fail(`${path}.base.id`, 'must equal id');
			}
			break;
		}
		case 'item.move':
			str(cmd.id, `${path}.id`);
			position(cmd.base, `${path}.base`);
			position(cmd.value, `${path}.value`);
			break;
		case 'schedule.set': {
			const field = str(cmd.field, `${path}.field`);
			for (const key of ['base', 'value'] as const) {
				const at = `${path}.${key}`;
				jsonValue(cmd[key], at);
				if (field === 'ivaMode') {
					ivaMode(cmd[key], at);
				}
				setOwn(cmd, key, normalizeValue(cmd[key], at, entry => ({ schedule: { [field]: entry } }), doc => (doc.schedule as Obj)[field]));
			}
			break;
		}
		case 'doc.set':
			if (typeof cmd.key !== 'string' || !DOCUMENT_KEYS.has(cmd.key)) {
				fail(`${path}.key`, 'is not a document value key');
			}
			for (const key of ['base', 'value'] as const) {
				const at = `${path}.${key}`;
				jsonValue(cmd[key], at);
				setOwn(cmd, key, normalizeValue(cmd[key], at, entry => ({ [cmd.key as string]: entry }), doc => doc[cmd.key as string]));
			}
			break;
	}
};

/**
 * Validates a client batch: UUID mutationId, revision, 1..5000 known
 * commands. Money values are normalized in place, as in parseDocument.
 * Returns the input.
 */
export const parseCommandBatch = (value: unknown): BudgetCommandBatch => {
	const batch = obj(value, '');
	if (typeof batch.mutationId !== 'string' || !UUID.test(batch.mutationId)) {
		fail('mutationId', 'must be a UUID');
	}
	if (!Number.isSafeInteger(batch.baseRevision) || (batch.baseRevision as number) < 0) {
		fail('baseRevision', 'must be an integer >= 0');
	}
	if (!Array.isArray(batch.commands) || batch.commands.length < 1 || batch.commands.length > MAX_COMMANDS) {
		fail('commands', `must be an array of 1 to ${MAX_COMMANDS} commands`);
	}
	(batch.commands as unknown[]).forEach((entry, i) => command(entry, `commands[${i}]`));
	return value as BudgetCommandBatch;
};
