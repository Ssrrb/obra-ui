/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

import type { ApplyResult, BudgetCommand, BudgetConflict, ItemPosition, JsonValue } from './contracts';
import { sameJson } from './canonical';
import { getOwn, positionsOf, sameContent, setOwn, stripDerived } from './items';
import { recalculateItems } from './opencalc/calculation/calculator';
import type { CostItem, ProjectFile } from './opencalc/types/costModel';

type Code = BudgetConflict['code'];

const touches = (command: BudgetCommand, ids: ReadonlySet<string>): boolean => {
	switch (command.type) {
		case 'item.insert':
			return ids.has(command.item.id);
		case 'item.set':
		case 'item.delete':
		case 'item.move':
			return ids.has(command.id);
		default:
			return false;
	}
};

/**
 * Applies every command or none. Preconditions are checked against the
 * input; parents and anchors when each command applies; the tree (no
 * orphan, no cycle) after the last one. The result is recalculated the way
 * upstream's store does: tariffs only feed labor prices when the batch
 * changes `schedule.tarieven` (upstream `updateTarieven`).
 */
export const applyCommands = (input: ProjectFile, commands: readonly BudgetCommand[]): ApplyResult => {
	const conflicts: BudgetConflict[] = [];
	const conflict = (index: number, code: Code, current?: unknown): void => {
		const command = commands[index]!;
		conflicts.push(current === undefined ? { index, code, command } : { index, code, command, current: current as JsonValue });
	};

	const preById = new Map(input.items.map(item => [item.id, item]));
	const prePositions = positionsOf(input.items);
	const skip = new Set<number>();

	commands.forEach((command, index) => {
		switch (command.type) {
			case 'item.set': {
				const item = preById.get(command.id);
				if (!item) {
					conflict(index, 'item_missing');
					break;
				}
				const current = getOwn(item, command.field);
				if (!sameJson(current, command.base) && !sameJson(current, command.value)) {
					conflict(index, 'precondition_failed', current);
				}
				break;
			}
			case 'item.insert': {
				const existing = preById.get(command.item.id);
				if (existing) {
					if (sameContent(existing, command.item)) {
						skip.add(index);
					} else {
						conflict(index, 'item_exists', stripDerived(existing));
					}
				}
				break;
			}
			case 'item.delete': {
				const existing = preById.get(command.id);
				if (!existing) {
					skip.add(index);
				} else if (!sameContent(existing, command.base)) {
					conflict(index, 'precondition_failed', stripDerived(existing));
				}
				break;
			}
			case 'item.move': {
				const current = prePositions.get(command.id);
				if (!current) {
					conflict(index, 'item_missing');
				} else if (current.parentId !== command.base.parentId && current.parentId !== command.value.parentId) {
					conflict(index, 'precondition_failed', current);
				}
				break;
			}
			case 'schedule.set': {
				const current = getOwn(input.schedule, command.field);
				if (!sameJson(current, command.base) && !sameJson(current, command.value)) {
					conflict(index, 'precondition_failed', current);
				}
				break;
			}
			case 'doc.set': {
				const current = getOwn(input, command.key);
				if (!sameJson(current, command.base) && !sameJson(current, command.value)) {
					conflict(index, 'precondition_failed', current);
				}
				break;
			}
		}
	});
	if (conflicts.length > 0) {
		return { ok: false, conflicts };
	}

	const doc = structuredClone(input);
	const items = doc.items;
	const indexOf = (id: string): number => items.findIndex(item => item.id === id);

	/** Index to insert at for `position`, or the conflict that prevents it. */
	const slot = (position: ItemPosition, self?: string): number | Code => {
		if (position.parentId !== null && indexOf(position.parentId) < 0) {
			return 'parent_missing';
		}
		if (position.afterId === null) {
			const first = items.findIndex(item => item.parentId === position.parentId && item.id !== self);
			return first < 0 ? items.length : first;
		}
		const anchor = items.findIndex(item => item.id === position.afterId && item.parentId === position.parentId);
		return anchor < 0 || position.afterId === self ? 'anchor_missing' : anchor + 1;
	};

	commands.forEach((command, index) => {
		if (skip.has(index)) {
			return;
		}
		switch (command.type) {
			case 'item.set': {
				const at = indexOf(command.id);
				if (at < 0) {
					conflict(index, 'item_missing');
				} else {
					setOwn(items[at]!, command.field, structuredClone(command.value));
				}
				break;
			}
			case 'item.insert': {
				if (indexOf(command.item.id) >= 0) {
					conflict(index, 'item_exists');
					break;
				}
				const at = slot(command.position);
				if (typeof at === 'string') {
					conflict(index, at);
					break;
				}
				// Derived fields start as upstream creates a row; recalculation fills them.
				const item: CostItem = { ...stripDerived(structuredClone(command.item)), parentId: command.position.parentId, unitPrice: '0', total: '0', depth: 0, sortOrder: 0, nr: '' };
				items.splice(at, 0, item);
				break;
			}
			case 'item.delete': {
				const at = indexOf(command.id);
				if (at >= 0) {
					items.splice(at, 1);
				}
				break;
			}
			case 'item.move': {
				const from = indexOf(command.id);
				if (from < 0) {
					conflict(index, 'item_missing');
					break;
				}
				const check = slot(command.value, command.id);
				if (typeof check === 'string') {
					conflict(index, check);
					break;
				}
				const item = items.splice(from, 1)[0]!;
				item.parentId = command.value.parentId;
				items.splice(slot(command.value) as number, 0, item);
				break;
			}
			case 'schedule.set':
				setOwn(doc.schedule, command.field, structuredClone(command.value));
				break;
			case 'doc.set':
				setOwn(doc, command.key, structuredClone(command.value));
				break;
		}
	});
	if (conflicts.length > 0) {
		return { ok: false, conflicts };
	}

	const blame = (ids: ReadonlySet<string>): number => {
		for (let i = commands.length - 1; i >= 0; i--) {
			if (touches(commands[i]!, ids)) {
				return i;
			}
		}
		return commands.length - 1;
	};
	const byId = new Map(items.map(item => [item.id, item]));
	const done = new Set<string>();
	for (const item of items) {
		if (item.parentId !== null && !byId.has(item.parentId)) {
			conflict(blame(new Set([item.id, item.parentId])), 'orphan');
		}
		const path: string[] = [];
		const onPath = new Set<string>();
		for (let node: CostItem | undefined = item; node && !done.has(node.id); node = byId.get(node.parentId ?? '')) {
			if (onPath.has(node.id)) {
				const cycle = new Set(path.slice(path.indexOf(node.id)));
				conflict(blame(cycle), 'cycle');
				break;
			}
			path.push(node.id);
			onPath.add(node.id);
		}
		for (const id of path) {
			done.add(id);
		}
	}
	if (conflicts.length > 0) {
		return { ok: false, conflicts };
	}

	const tariffsChanged = commands.some(command => command.type === 'schedule.set' && command.field === 'tarieven');
	doc.items = recalculateItems(items, tariffsChanged ? doc.schedule.tarieven : undefined);
	return { ok: true, document: doc };
};
