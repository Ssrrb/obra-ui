/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

/**
 * Web Crypto subset present in every target runtime (Node >= 19, Workers,
 * webviews). Declared here because the package compiles without DOM or
 * Node types.
 */
declare const crypto: {
	randomUUID(): string;
};

/** HTML structured clone, present in the same runtimes. */
declare function structuredClone<T>(value: T): T;
