/*---------------------------------------------------------------------------------------------
 *  Copyright (c) Obra Studio. All rights reserved.
 *--------------------------------------------------------------------------------------------*/

/** Input rejected at a trust boundary; `path` points at the offending value. */
export class BudgetValidationError extends Error {
	override readonly name = 'BudgetValidationError';

	constructor(readonly path: string, message: string) {
		super(`${path || '(root)'}: ${message}`);
	}
}
