# Provenance

Files under `src/opencalc/` come from OpenCalc Studio.

- Upstream: https://github.com/OpenAEC-Foundation/open-calc-studio
- Commit: `b47042704efa388d95eb59ce77d23aeb5ee0e44c`
- Version: 0.13.0 (`package.json` at that commit)

The import commit holds byte-identical copies. Later commits only adapt
imports so the files compile here; see `git log -- src/opencalc`.

| Local path | Upstream path | sha256 of the upstream file |
| --- | --- | --- |
| `src/opencalc/types/costModel.ts` | `src/types/costModel.ts` | `5976bd4491bd137805c0c21660478c1d7cbece8cf2892d64918b25df14e56644` |
| `src/opencalc/calculation/calculator.ts` | `src/services/calculation/calculator.ts` | `20cc5417d95c275d4037a8f0bcb4e1494c7d21165333ad42a5d21b1515dd04ee` |
| `src/opencalc/calculation/staartDefaults.ts` | `src/services/calculation/staartDefaults.ts` | `470d4b1df3691a88d27873e43caf11ff103970d9a4972f94d198d271d14c8132` |
| `src/opencalc/calculation/urenProrate.ts` | `src/services/calculation/urenProrate.ts` | `359d8579a01f37753db1ce2242bcab2685f83a994ea3b08cfcb11c702bacaac9` |
| `src/opencalc/test/calculator.test.ts` | `src/test/calculator.test.ts` | `8cbff4c407304da945d90f5ab76915adeba1618a24a3ad960834a3a4dd07b9f5` |
| `src/opencalc/test/kostprijsBreakdown.test.ts` | `src/test/kostprijsBreakdown.test.ts` | `a48c5ac5194ffc79472885c11d3cda5b6cbcf41f2194932504a5d32a8a30bf9b` |
| `src/opencalc/test/normalizeOrder.test.ts` | `src/test/normalizeOrder.test.ts` | `fdb57037c8bd21f184d6391e6072ed479627f9d4289ba438e44c17c513a23374` |
| `src/opencalc/test/staartBtwLaag.test.ts` | `src/test/staartBtwLaag.test.ts` | `5ca0a25bcb464a0fe24f1d155522c9ef811c2eb2f348b6b264fb342a884947c7` |
| `src/opencalc/test/staartIntegration.test.ts` | `src/test/staartIntegration.test.ts` | `73892c6506e7a672d8c26efec1c5363b53df8147db6faef7d1dd2e13f18a6fa4` |
| `src/opencalc/test/staartItemBreakdown.test.ts` | `src/test/staartItemBreakdown.test.ts` | `0de6b7a42aba750a812c86c9cb1be0572fee65afb540bb672bb00ab0b9bdad28` |
| `src/opencalc/test/urenNaarRato.test.ts` | `src/test/urenNaarRato.test.ts` | `8ac6d93a550c0328c02477e5d153352021299577e8588763dfda802ee1853c68` |

The tests are the upstream tests whose only project imports are these files.

## Adaptations

- Imports of `@/types/costModel` use relative paths.
- `calculator.ts` `normalizeItemOrder`: `kids[i]!` so the file passes
  `noUncheckedIndexedAccess` when the API type-checks it. Behavior is unchanged.

### Schema 2: decimal money (ctrl.2, engine `0.13.0+ctrl.2`)

Money policy and field list: `src/contracts.ts`. Arithmetic: decimal.js only,
through the isolated `Dec` of `src/decimal.ts` (80 digits, HALF_UP).

- `types/costModel.ts`: `DecimalString` (or `| null`) for CostItem `quantity`,
  `materialPrice`, `laborPrice`, `unitPrice`, `total`, `staartPercentage`,
  `norm*`, `staartDoelbedrag`, `staartVastBedrag`, `staartAfrondingStap`,
  `staartBtwBasis`; CostSchedule `uitvoeringskosten`, `algemeneKosten`,
  `winstRisico`, `tarieven` values; StagartRow amounts (not `itemtype`); every
  StaartItemBreakdown field; ResourceLibraryItem `defaultUnitPrice`;
  ProjectSnapshot `totaalExclBtw`. New: CostItem `ivaRate?: IvaRate | null`,
  CostSchedule `ivaMode?: IvaMode`. Offerte prices, ProjectProperty values,
  FieldChange values and SubSheet cells stay numbers.
- `calculation/calculator.ts`, ported to decimals with upstream's passes:
  - line amounts (regel, childless post, a post's own price) are quantized to
    2 decimals HALF_UP; a regel's `unitPrice` keeps the unrounded amount
    (upstream: `total = unitPrice`); other derived values (unit prices,
    `laborPrice = norm × tarief`) are rounded to 12 fraction digits, the most a
    DecimalString holds; an amount beyond 24 integer digits throws
    BudgetValidationError;
  - every staart markup is quantized to 2 decimals on its base; ABK-type rows
    split the quantized amount over loon/materiaal/materieel with the rounding
    rest on the largest base; `staart_ak_oa` now reports its base in `bedrag`
    (upstream 0); `staartVastBedrag` and `staartDoelbedrag` are quantized to 2
    decimals; afronding steps round HALF_UP (upstream `Math.round`, which
    rounds negative halves toward +infinity);
  - `computeKostprijsBreakdown`: with a labor split, loon is the quantized
    labor part and the resource column the rest of the line amount (upstream:
    unrounded `normUnitPrice × quantity`), so the columns sum to the line;
  - `staart_btw` / `staart_btw_laag` contribute zero (upstream: Dutch VAT
    hoog/laag over the excl. total); `btwTarief` feeds nothing.
    `computeBtwLaagDirect` is kept for upstream callers. IVA lives in
    `src/totals.ts` (`computeTotals`);
  - identical upstream branches are merged and `getStaartBreakdown` reads the
    rows through a per-type lookup; results are the same.
- `calculation/staartDefaults.ts`: percentages as decimal strings.
- `calculation/urenProrate.ts`: decimals; uren totals return DecimalString,
  `prorate*` take `newTotal` as DecimalString, rescaled norms keep 12 fraction
  digits.
- Tests: numbers become decimal strings and `toBeCloseTo` becomes exact
  `toBe`; every expectation changed by the policy has a `before → after`
  comment (all of them are the VAT rows above).
- `src/expression.ts` ports upstream `src/utils/numericInput.ts` and
  `parseNlNumber` (`src/utils/formatting.ts`) to decimals, as
  `evaluateDecimalExpression` and `parseDecimalInput`.

## License status: distribution blocked

- `README.md` (badge and "License" section) and `packages/embed/package.json`
  (`"license": "MIT"`) declare MIT.
- No `LICENSE` file exists at that commit, although the README links to one.
  GitHub reports the repository license as null.
- MIT requires the copyright notice and permission notice to ship with the
  software. Without an authentic notice from the authors we cannot reproduce
  it, and this file does not invent one.

Until the upstream authors publish a LICENSE file (or confirm the notice in
writing), this package must not be distributed outside Obra Studio.
